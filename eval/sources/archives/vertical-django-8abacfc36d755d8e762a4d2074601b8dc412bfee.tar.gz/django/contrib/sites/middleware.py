from django.middleware import MiddlewareMixin

from .shortcuts import get_current_site


class CurrentSiteMiddleware(MiddlewareMixin):
    """
    Middleware that sets `site` attribute to request object.
    """

    async_capable = False

    def process_request(self, request):
        request.site = get_current_site(request)
