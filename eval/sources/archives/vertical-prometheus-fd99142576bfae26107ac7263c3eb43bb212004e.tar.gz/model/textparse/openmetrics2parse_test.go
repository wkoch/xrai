// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package textparse

import (
	"io"
	"math"
	"strings"
	"testing"

	"github.com/prometheus/common/model"
	"github.com/stretchr/testify/require"

	"github.com/prometheus/prometheus/model/exemplar"
	"github.com/prometheus/prometheus/model/histogram"
	"github.com/prometheus/prometheus/model/labels"
)

func TestOpenMetrics2Parse(t *testing.T) {
	input := `# HELP go_gc_duration_seconds A summary of GC invocation durations.
# TYPE go_gc_duration_seconds summary
# UNIT go_gc_duration_seconds seconds
go_gc_duration_seconds {count:99,sum:0.004,quantile:[0:4.9351e-05,0.5:8.3835e-05]}
# TYPE go_goroutines gauge
go_goroutines 33 123456.789
# TYPE hh histogram
hh {count:1,sum:1.0,bucket:[+Inf:1]}
# TYPE ii_info info
ii_info{foo="bar"} 1
# TYPE ss stateset
ss{ss="foo"} 1
ss{ss="bar"} 0
# TYPE un unknown
un 1
# TYPE foo_total counter
foo_total 17.0 1520879607.789 # {id="counter-test"} 5 1520879600.789
# EOF
`

	exp := []parsedEntry{
		{m: "go_gc_duration_seconds", help: "A summary of GC invocation durations."},
		{m: "go_gc_duration_seconds", typ: model.MetricTypeSummary},
		{m: "go_gc_duration_seconds", unit: "seconds"},
		{
			m:    "go_gc_duration_seconds_count",
			v:    99,
			lset: labels.FromStrings("__name__", "go_gc_duration_seconds_count"),
		},
		{
			m:    "go_gc_duration_seconds_sum",
			v:    0.004,
			lset: labels.FromStrings("__name__", "go_gc_duration_seconds_sum"),
		},
		{
			m:    "go_gc_duration_seconds\xffquantile\xff0.0",
			v:    4.9351e-05,
			lset: labels.FromStrings("__name__", "go_gc_duration_seconds", "quantile", "0.0"),
		},
		{
			m:    "go_gc_duration_seconds\xffquantile\xff0.5",
			v:    8.3835e-05,
			lset: labels.FromStrings("__name__", "go_gc_duration_seconds", "quantile", "0.5"),
		},
		{m: "go_goroutines", typ: model.MetricTypeGauge},
		{
			m:    "go_goroutines",
			v:    33,
			t:    int64p(123456789),
			lset: labels.FromStrings("__name__", "go_goroutines"),
		},
		{m: "hh", typ: model.MetricTypeHistogram},
		{
			m:    "hh_count",
			v:    1,
			lset: labels.FromStrings("__name__", "hh_count"),
		},
		{
			m:    "hh_sum",
			v:    1.0,
			lset: labels.FromStrings("__name__", "hh_sum"),
		},
		{
			m:    "hh_bucket\xffle\xff+Inf",
			v:    1,
			lset: labels.FromStrings("__name__", "hh_bucket", "le", "+Inf"),
		},
		{m: "ii_info", typ: model.MetricTypeInfo},
		{
			m:    `ii_info{foo="bar"}`,
			v:    1,
			lset: labels.FromStrings("__name__", "ii_info", "foo", "bar"),
		},
		{m: "ss", typ: model.MetricTypeStateset},
		{
			m:    `ss{ss="foo"}`,
			v:    1,
			lset: labels.FromStrings("__name__", "ss", "ss", "foo"),
		},
		{
			m:    `ss{ss="bar"}`,
			v:    0,
			lset: labels.FromStrings("__name__", "ss", "ss", "bar"),
		},
		{m: "un", typ: model.MetricTypeUnknown},
		{
			m:    "un",
			v:    1,
			lset: labels.FromStrings("__name__", "un"),
		},
		{m: "foo_total", typ: model.MetricTypeCounter},
		{
			m:    "foo_total",
			v:    17.0,
			t:    int64p(1520879607789),
			lset: labels.FromStrings("__name__", "foo_total"),
			es:   []exemplar.Exemplar{{Labels: labels.FromStrings("id", "counter-test"), Value: 5, HasTs: true, Ts: 1520879600789}},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseStartTimestamp(t *testing.T) {
	input := `# TYPE requests_total counter
requests_total 42.0 1000000.0 st@500000.0
# EOF
`
	exp := []parsedEntry{
		{m: "requests_total", typ: model.MetricTypeCounter},
		{
			m:    "requests_total",
			v:    42.0,
			t:    int64p(1000000000),
			st:   500000000,
			lset: labels.FromStrings("__name__", "requests_total"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseStartTimestampNoMainTimestamp(t *testing.T) {
	input := `# TYPE requests_total counter
requests_total 42.0 st@500000.0
# EOF
`
	exp := []parsedEntry{
		{m: "requests_total", typ: model.MetricTypeCounter},
		{
			m:    "requests_total",
			v:    42.0,
			st:   500000000,
			lset: labels.FromStrings("__name__", "requests_total"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseMultipleExemplars(t *testing.T) {
	input := `# TYPE foo_total counter
foo_total 17.0 # {id="a"} 1.0 1234566.0 # {id="b"} 2.0 1234567.0
# EOF
`
	exp := []parsedEntry{
		{m: "foo_total", typ: model.MetricTypeCounter},
		{
			m:    "foo_total",
			v:    17.0,
			lset: labels.FromStrings("__name__", "foo_total"),
			es: []exemplar.Exemplar{
				{Labels: labels.FromStrings("id", "a"), Value: 1.0, HasTs: true, Ts: 1234566000},
				{Labels: labels.FromStrings("id", "b"), Value: 2.0, HasTs: true, Ts: 1234567000},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseExemplarMultipleLabels(t *testing.T) {
	input := `# TYPE http_requests_total counter
http_requests_total 1027 1710000000.0 # {trace_id="abc123",span_id="def456"} 1.0 1709999999.0
# EOF
`
	exp := []parsedEntry{
		{m: "http_requests_total", typ: model.MetricTypeCounter},
		{
			m:    "http_requests_total",
			v:    1027,
			t:    int64p(1710000000000),
			lset: labels.FromStrings("__name__", "http_requests_total"),
			es: []exemplar.Exemplar{
				{
					Labels: labels.FromStrings("span_id", "def456", "trace_id", "abc123"),
					Value:  1.0,
					HasTs:  true,
					Ts:     1709999999000,
				},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseExemplarExceedsOM1Limit(t *testing.T) {
	// OM1 capped exemplar LabelSets at 128 UTF-8 code points (sum of all
	// label names and values).  OM2 removes that cap; this exemplar is
	// well over the old limit (4 + 200 = 204 code points).
	longValue := strings.Repeat("x", 200)
	input := `# TYPE foo_total counter
foo_total 1.0 # {data="` + longValue + `"} 1.0 1234567.0
# EOF
`
	exp := []parsedEntry{
		{m: "foo_total", typ: model.MetricTypeCounter},
		{
			m:    "foo_total",
			v:    1.0,
			lset: labels.FromStrings("__name__", "foo_total"),
			es: []exemplar.Exemplar{
				{
					Labels: labels.FromStrings("data", longValue),
					Value:  1.0,
					HasTs:  true,
					Ts:     1234567000,
				},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseExemplarQuotedUTF8LabelKey(t *testing.T) {
	// OM2 label-key allows DQUOTE escaped-string-non-empty DQUOTE, permitting
	// label names that contain characters invalid in plain identifiers (e.g. ".").
	// parseExemplarLVals only accepted tLName; replacing it with parseLVals
	// (isExemplar=true) adds tQString support.
	input := `# TYPE hits gauge
hits 17.0 # {"my.id"="abc"} 5 1520879600.789
# EOF
`
	exp := []parsedEntry{
		{m: "hits", typ: model.MetricTypeGauge},
		{
			m:    "hits",
			v:    17.0,
			lset: labels.FromStrings("__name__", "hits"),
			es:   []exemplar.Exemplar{{Labels: labels.FromStrings("my.id", "abc"), Value: 5, HasTs: true, Ts: 1520879600789}},
		},
	}
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseCompositeClassicGaugeHistogram verifies that a classic
// GaugeHistogram composite value exposes its count/sum as gcount/gsum, not
// count/sum, per the OM2 spec:
// https://prometheus.io/docs/specs/om/open_metrics_spec_2_0/#gaugehistogram-1
func TestOpenMetrics2ParseCompositeClassicGaugeHistogram(t *testing.T) {
	input := `# TYPE foo gaugehistogram
foo {gcount:42,gsum:3289.3,bucket:[0.01:20,0.1:25,1:34,+Inf:42]}
# EOF
`
	exp := []parsedEntry{
		{m: "foo", typ: model.MetricTypeGaugeHistogram},
		{
			m:    "foo_gcount",
			v:    42,
			lset: labels.FromStrings("__name__", "foo_gcount"),
		},
		{
			m:    "foo_gsum",
			v:    3289.3,
			lset: labels.FromStrings("__name__", "foo_gsum"),
		},
		{
			m:    "foo_bucket\xffle\xff0.01",
			v:    20,
			lset: labels.FromStrings("__name__", "foo_bucket", "le", "0.01"),
		},
		{
			m:    "foo_bucket\xffle\xff0.1",
			v:    25,
			lset: labels.FromStrings("__name__", "foo_bucket", "le", "0.1"),
		},
		{
			m:    "foo_bucket\xffle\xff1.0",
			v:    34,
			lset: labels.FromStrings("__name__", "foo_bucket", "le", "1.0"),
		},
		{
			m:    "foo_bucket\xffle\xff+Inf",
			v:    42,
			lset: labels.FromStrings("__name__", "foo_bucket", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseCompositeSummary(t *testing.T) {
	input := `# HELP rpc_duration_seconds RPC duration.
# TYPE rpc_duration_seconds summary
rpc_duration_seconds {count:100,sum:30000.0,quantile:[0.5:100.0,0.9:200.0,0.99:300.0]}
# EOF
`
	exp := []parsedEntry{
		{m: "rpc_duration_seconds", help: "RPC duration."},
		{m: "rpc_duration_seconds", typ: model.MetricTypeSummary},
		// Exploded series: _count, _sum, quantile entries.
		{
			m:    "rpc_duration_seconds_count",
			v:    100,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds_count"),
		},
		{
			m:    "rpc_duration_seconds_sum",
			v:    30000.0,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds_sum"),
		},
		{
			m:    "rpc_duration_seconds\xffquantile\xff0.5",
			v:    100.0,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds", "quantile", "0.5"),
		},
		{
			m:    "rpc_duration_seconds\xffquantile\xff0.9",
			v:    200.0,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds", "quantile", "0.9"),
		},
		{
			m:    "rpc_duration_seconds\xffquantile\xff0.99",
			v:    300.0,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds", "quantile", "0.99"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseCompositeClassicHistogram(t *testing.T) {
	input := `# HELP req_duration Request duration histogram.
# TYPE req_duration histogram
req_duration {count:3,sum:6.0,bucket:[0.1:1,1.0:2,+Inf:3]}
# EOF
`
	exp := []parsedEntry{
		{m: "req_duration", help: "Request duration histogram."},
		{m: "req_duration", typ: model.MetricTypeHistogram},
		{
			m:    "req_duration_count",
			v:    3,
			lset: labels.FromStrings("__name__", "req_duration_count"),
		},
		{
			m:    "req_duration_sum",
			v:    6.0,
			lset: labels.FromStrings("__name__", "req_duration_sum"),
		},
		{
			m:    "req_duration_bucket\xffle\xff0.1",
			v:    1,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "0.1"),
		},
		{
			m:    "req_duration_bucket\xffle\xff1.0",
			v:    2,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "1.0"),
		},
		{
			m:    "req_duration_bucket\xffle\xff+Inf",
			v:    3,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseClassicHistogramNegInfBucket verifies that -Inf is
// accepted as the first classic histogram bucket threshold, as permitted by the
// OM2 ABNF.
func TestOpenMetrics2ParseClassicHistogramNegInfBucket(t *testing.T) {
	input := `# TYPE req_duration histogram
req_duration {count:3,sum:6.0,bucket:[-Inf:1,1.0:2,+Inf:3]}
# EOF
`
	exp := []parsedEntry{
		{m: "req_duration", typ: model.MetricTypeHistogram},
		{
			m:    "req_duration_count",
			v:    3,
			lset: labels.FromStrings("__name__", "req_duration_count"),
		},
		{
			m:    "req_duration_sum",
			v:    6.0,
			lset: labels.FromStrings("__name__", "req_duration_sum"),
		},
		{
			m:    "req_duration_bucket\xffle\xff-Inf",
			v:    1,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "-Inf"),
		},
		{
			m:    "req_duration_bucket\xffle\xff1.0",
			v:    2,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "1.0"),
		},
		{
			m:    "req_duration_bucket\xffle\xff+Inf",
			v:    3,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseCompositeNativeAndClassicHistogram(t *testing.T) {
	// A composite value exposing both representations in one line: native
	// histogram fields (schema, positive_spans, positive_buckets, ...) AND a
	// classic bucket list. The KeepClassicOnNativeHistogram option mirrors
	// the protobuf parser's parseClassicHistograms flag: when off, only the
	// native histogram is emitted and the classic bucket list is dropped;
	// when on, classic _count/_sum/_bucket flat series are also emitted.
	input := `# HELP req_duration Request duration histogram with both representations.
# TYPE req_duration histogram
req_duration {count:3,sum:6.0,schema:0,zero_threshold:0.001,zero_count:0,positive_spans:[0:2],positive_buckets:[1,2],bucket:[0.1:1,1.0:2,+Inf:3]}
# EOF
`
	header := []parsedEntry{
		{m: "req_duration", help: "Request duration histogram with both representations."},
		{m: "req_duration", typ: model.MetricTypeHistogram},
	}
	nativeEntry := parsedEntry{
		m:    "req_duration",
		lset: labels.FromStrings("__name__", "req_duration"),
		shs: &histogram.Histogram{
			Schema:          0,
			ZeroThreshold:   0.001,
			ZeroCount:       0,
			Count:           3,
			Sum:             6.0,
			PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
			PositiveBuckets: []int64{1, 1},
		},
	}
	classicSeries := []parsedEntry{
		{m: "req_duration_count", v: 3, lset: labels.FromStrings("__name__", "req_duration_count")},
		{m: "req_duration_sum", v: 6.0, lset: labels.FromStrings("__name__", "req_duration_sum")},
		{m: "req_duration_bucket\xffle\xff0.1", v: 1, lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "0.1")},
		{m: "req_duration_bucket\xffle\xff1.0", v: 2, lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "1.0")},
		{m: "req_duration_bucket\xffle\xff+Inf", v: 3, lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "+Inf")},
	}

	for _, tc := range []struct {
		name string
		opts ParserOptions
		exp  []parsedEntry
	}{
		{
			name: "keep_classic_off",
			exp:  append(append([]parsedEntry{}, header...), nativeEntry),
		},
		{
			name: "keep_classic_on",
			opts: ParserOptions{KeepClassicOnClassicAndNativeHistograms: true},
			exp:  append(append(append([]parsedEntry{}, header...), nativeEntry), classicSeries...),
		},
		{
			name: "convert_nhcb_keep_classic_off",
			opts: ParserOptions{ConvertClassicHistogramsToNHCB: true},
			exp:  append(append([]parsedEntry{}, header...), nativeEntry),
		},
		{
			name: "convert_nhcb_keep_classic_on",
			opts: ParserOptions{ConvertClassicHistogramsToNHCB: true, KeepClassicOnClassicAndNativeHistograms: true},
			exp:  append(append(append([]parsedEntry{}, header...), nativeEntry), classicSeries...),
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), tc.opts)
			got := testParse(t, p)
			requireEntries(t, tc.exp, got)
		})
	}
}

func TestOpenMetrics2ParseConvertClassicHistogramToNHCB(t *testing.T) {
	ts := int64(1234567000)
	for _, tc := range []struct {
		name  string
		input string
		opts  ParserOptions
		exp   []parsedEntry
	}{
		{
			name: "classic_int_histogram_to_nhcb",
			input: `# HELP req_duration Request duration.
# TYPE req_duration histogram
# UNIT req_duration seconds
req_duration{job="api"} {count:3,sum:6.0,bucket:[0.1:1,1.0:2,+Inf:3]} 1234567.0 st@1000.0 # {id="req-1"} 0.8 1234566.0
# EOF
`,
			opts: ParserOptions{ConvertClassicHistogramsToNHCB: true, EnableTypeAndUnitLabels: true},
			exp: []parsedEntry{
				{m: "req_duration", help: "Request duration."},
				{m: "req_duration", typ: model.MetricTypeHistogram},
				{m: "req_duration", unit: "seconds"},
				{
					m:    `req_duration{job="api"}`,
					lset: labels.FromStrings("__name__", "req_duration", "__type__", "histogram", "__unit__", "seconds", "job", "api"),
					t:    &ts,
					st:   1000000,
					es:   []exemplar.Exemplar{{Labels: labels.FromStrings("id", "req-1"), Value: 0.8, HasTs: true, Ts: 1234566000}},
					shs: &histogram.Histogram{
						Schema:          histogram.CustomBucketsSchema,
						Count:           3,
						Sum:             6.0,
						PositiveSpans:   []histogram.Span{{Offset: 0, Length: 3}},
						PositiveBuckets: []int64{1, 0, 0},
						CustomValues:    []float64{0.1, 1.0},
					},
				},
			},
		},
		{
			// Corresponds to convert_classic_histograms_to_nhcb: true and
			// always_scrape_classic_histograms: true in scrape config (see #13532),
			// emitting both the converted NHCB and the classic histogram series.
			name: "classic_int_histogram_to_nhcb_with_keep_classic",
			input: `# TYPE req_duration histogram
req_duration {count:3,sum:6.0,bucket:[0.1:1,1.0:2,+Inf:3]} 1234567.0 st@1000.0 # {id="req-1"} 0.8 1234566.0
# EOF
`,
			opts: ParserOptions{ConvertClassicHistogramsToNHCB: true, KeepClassicOnClassicAndNativeHistograms: true},
			exp: []parsedEntry{
				{m: "req_duration", typ: model.MetricTypeHistogram},
				{
					m:    "req_duration",
					lset: labels.FromStrings("__name__", "req_duration"),
					t:    &ts,
					st:   1000000,
					es:   []exemplar.Exemplar{{Labels: labels.FromStrings("id", "req-1"), Value: 0.8, HasTs: true, Ts: 1234566000}},
					shs: &histogram.Histogram{
						Schema:          histogram.CustomBucketsSchema,
						Count:           3,
						Sum:             6.0,
						PositiveSpans:   []histogram.Span{{Offset: 0, Length: 3}},
						PositiveBuckets: []int64{1, 0, 0},
						CustomValues:    []float64{0.1, 1.0},
					},
				},
				{m: "req_duration_count", v: 3, t: &ts, st: 1000000, lset: labels.FromStrings("__name__", "req_duration_count")},
				{m: "req_duration_sum", v: 6.0, t: &ts, st: 1000000, lset: labels.FromStrings("__name__", "req_duration_sum")},
				{m: "req_duration_bucket\xffle\xff0.1", v: 1, t: &ts, st: 1000000, lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "0.1")},
				{m: "req_duration_bucket\xffle\xff1.0", v: 2, t: &ts, st: 1000000, lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "1.0")},
				{m: "req_duration_bucket\xffle\xff+Inf", v: 3, t: &ts, st: 1000000, lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "+Inf")},
			},
		},
		{
			name: "classic_float_histogram_to_nhcb",
			input: `# TYPE req_duration histogram
req_duration {count:3.5,sum:6.0,bucket:[0.1:1.5,1.0:2.5,+Inf:3.5]}
# EOF
`,
			opts: ParserOptions{ConvertClassicHistogramsToNHCB: true},
			exp: []parsedEntry{
				{m: "req_duration", typ: model.MetricTypeHistogram},
				{
					m:    "req_duration",
					lset: labels.FromStrings("__name__", "req_duration"),
					fhs: &histogram.FloatHistogram{
						Schema:          histogram.CustomBucketsSchema,
						Count:           3.5,
						Sum:             6.0,
						PositiveSpans:   []histogram.Span{{Offset: 0, Length: 3}},
						PositiveBuckets: []float64{1.5, 1.0, 1.0},
						CustomValues:    []float64{0.1, 1.0},
					},
				},
			},
		},
		{
			name: "classic_gaugehistogram_to_nhcb",
			input: `# TYPE queue_size gaugehistogram
queue_size {gcount:4,gsum:100.0,bucket:[10:1,50:3,+Inf:4]}
# EOF
`,
			opts: ParserOptions{ConvertClassicHistogramsToNHCB: true},
			exp: []parsedEntry{
				{m: "queue_size", typ: model.MetricTypeGaugeHistogram},
				{
					m:    "queue_size",
					lset: labels.FromStrings("__name__", "queue_size"),
					shs: &histogram.Histogram{
						CounterResetHint: histogram.GaugeType,
						Schema:           histogram.CustomBucketsSchema,
						Count:            4,
						Sum:              100.0,
						PositiveSpans:    []histogram.Span{{Offset: 0, Length: 3}},
						PositiveBuckets:  []int64{1, 1, -1},
						CustomValues:     []float64{10, 50},
					},
				},
			},
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(tc.input), labels.NewSymbolTable(), tc.opts)
			got := testParse(t, p)
			requireEntries(t, tc.exp, got)
		})
	}
}

func TestOpenMetrics2ParseNativeHistogram(t *testing.T) {
	input := `# HELP test_histogram Native histogram.
# TYPE test_histogram histogram
test_histogram {count:6,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,negative_spans:[],negative_buckets:[],positive_spans:[0:3],positive_buckets:[1,2,1]}
# EOF
`
	exp := []parsedEntry{
		{m: "test_histogram", help: "Native histogram."},
		{m: "test_histogram", typ: model.MetricTypeHistogram},
		{
			m:    "test_histogram",
			lset: labels.FromStrings("__name__", "test_histogram"),
			shs: &histogram.Histogram{
				Schema:          0,
				ZeroThreshold:   0.001,
				ZeroCount:       2,
				Count:           6,
				Sum:             12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 3}},
				PositiveBuckets: []int64{1, 1, -1},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseNativeHistogramOmittedEmptyFields(t *testing.T) {
	// The OM2 spec says empty spans/buckets SHOULD be omitted; verify the
	// parser treats absent keys identically to explicit empty lists.
	input := `# TYPE test_histogram histogram
test_histogram {count:6,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:3],positive_buckets:[1,2,1]}
# EOF
`
	exp := []parsedEntry{
		{m: "test_histogram", typ: model.MetricTypeHistogram},
		{
			m:    "test_histogram",
			lset: labels.FromStrings("__name__", "test_histogram"),
			shs: &histogram.Histogram{
				Schema:          0,
				ZeroThreshold:   0.001,
				ZeroCount:       2,
				Count:           6,
				Sum:             12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 3}},
				PositiveBuckets: []int64{1, 1, -1},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseNativeHistogramOmittedPositiveFields(t *testing.T) {
	// Histogram with only negative buckets; positive_spans and positive_buckets are omitted.
	input := `# TYPE test_histogram histogram
test_histogram {count:6,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,negative_spans:[0:3],negative_buckets:[1,2,1]}
# EOF
`
	exp := []parsedEntry{
		{m: "test_histogram", typ: model.MetricTypeHistogram},
		{
			m:    "test_histogram",
			lset: labels.FromStrings("__name__", "test_histogram"),
			shs: &histogram.Histogram{
				Schema:          0,
				ZeroThreshold:   0.001,
				ZeroCount:       2,
				Count:           6,
				Sum:             12.1,
				NegativeSpans:   []histogram.Span{{Offset: 0, Length: 3}},
				NegativeBuckets: []int64{1, 1, -1},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseUTF8MetricName(t *testing.T) {
	input := `# TYPE "metric.name" gauge
{"metric.name",label="value"} 1.0
# EOF
`
	exp := []parsedEntry{
		{m: "metric.name", typ: model.MetricTypeGauge},
		{
			m:    `{"metric.name",label="value"}`,
			v:    1.0,
			lset: labels.FromStrings("__name__", "metric.name", "label", "value"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseUnknown(t *testing.T) {
	for _, tc := range []struct {
		name  string
		input string
		exp   []parsedEntry
	}{
		{
			name: "explicit help and type",
			input: `# HELP un Some unknown metric.
# TYPE un unknown
un 1
# EOF
`,
			exp: []parsedEntry{
				{m: "un", help: "Some unknown metric."},
				{m: "un", typ: model.MetricTypeUnknown},
				{
					m:    "un",
					v:    1,
					lset: labels.FromStrings("__name__", "un"),
				},
			},
		},
		{
			name: "no type declaration",
			input: `bare_metric 42
# EOF
`,
			exp: []parsedEntry{
				{
					m:    "bare_metric",
					v:    42,
					lset: labels.FromStrings("__name__", "bare_metric"),
				},
			},
		},
		{
			name: "explicit type and unit",
			input: `# TYPE un_seconds unknown
# UNIT un_seconds seconds
un_seconds 1.5
# EOF
`,
			exp: []parsedEntry{
				{m: "un_seconds", typ: model.MetricTypeUnknown},
				{m: "un_seconds", unit: "seconds"},
				{
					m:    "un_seconds",
					v:    1.5,
					lset: labels.FromStrings("__name__", "un_seconds"),
				},
			},
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(tc.input), labels.NewSymbolTable(), ParserOptions{})
			got := testParse(t, p)
			requireEntries(t, tc.exp, got)
		})
	}
}

func TestOpenMetrics2ParseErrors(t *testing.T) {
	for _, tc := range []struct {
		input string
		err   string
	}{
		{
			input: "metric 1.0\n",
			err:   "does not end with # EOF",
		},
		{
			input: "# EOF\nextra\n",
			err:   "unexpected data after # EOF",
		},
		{
			// Composite value with unknown type (no # TYPE before).
			input: `foo {count:1,sum:1.0}
# EOF
`,
			err: "composite value not supported",
		},
		{
			// OM2 requires every exemplar to carry a timestamp.
			input: `# TYPE foo_total counter
foo_total 1.0 # {id="x"} 1.0
# EOF
`,
			err: "expected exemplar timestamp",
		},
		{
			input: "# TYPE foo histogram\nfoo {sum:1.0,schema:0,zero_threshold:0,zero_count:0}\n# EOF\n",
			err:   "missing required field: count",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,schema:0,zero_threshold:0,zero_count:0}\n# EOF\n",
			err:   "missing required field: sum",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:0,zero_count:0}\n# EOF\n",
			err:   "missing required field: zero_threshold",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:0,zero_threshold:0}\n# EOF\n",
			err:   "missing required field: zero_count",
		},
		{
			input: "# TYPE requests_total counter\nrequests_total 42.0 1000000.0 2000000.0\n# EOF\n",
			err:   "duplicate timestamp",
		},
		{
			input: "# TYPE requests_total counter\nrequests_total 42.0 1000000.0 st@500000.0 st@600000.0\n# EOF\n",
			err:   "duplicate start timestamp",
		},
		{
			input: "# TYPE requests_total counter\nrequests_total 42.0 st@500000.0 1000000.0\n# EOF\n",
			err:   "timestamp must precede start timestamp",
		},
		{
			input: "# TYPE foo summary\nfoo {count:3,sum:6.0,quantile:[0.99:1.0,0.5:2.0]}\n# EOF\n",
			err:   "quantiles must be sorted in increasing order",
		},
		{
			input: "{\"a\xffb\"} 1.0\n# EOF\n",
			err:   "invalid UTF-8 metric name",
		},
		{
			input: "# TYPE \"a\xffb\" counter\n# EOF\n",
			err:   "invalid UTF-8 metric name",
		},
		{
			input: "# TYPE foo counter\nfoo{\"a\xffb\"=\"v\"} 1.0\n# EOF\n",
			err:   "invalid UTF-8 label name",
		},
		{
			input: "{\"\",label=\"v\"} 1.0\n# EOF\n",
			err:   "metric name must not be empty",
		},
		{
			input: "# TYPE \"\" counter\n# EOF\n",
			err:   "metric name must not be empty",
		},
		{
			input: "{label=\"v\",\"m.n\"} 1.0\n# EOF\n",
			err:   "metric name must be the first item in the label set",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:3,sum:6.0,bucket:[+Inf:3,0.1:1,1.0:2]}\n# EOF\n",
			err:   "classic histogram buckets must be sorted in increasing order",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,count:99,sum:2.0,bucket:[+Inf:1]}\n# EOF\n",
			err:   "duplicate composite field",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:5,sum:2.0,buckets:[1:3,+Inf:5]}\n# EOF\n",
			err:   "unknown composite field",
		},
		{
			input: "# TYPE foo summary\nfoo {count:1,sum:2.0,quantiles:[0.5:1.0]}\n# EOF\n",
			err:   "unknown composite field",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:9,zero_threshold:0,zero_count:0}\n# EOF\n",
			err:   "schema must be between -4 and 8",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:-5,zero_threshold:0,zero_count:0}\n# EOF\n",
			err:   "schema must be between -4 and 8",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:4294967296,zero_threshold:0,zero_count:0}\n# EOF\n",
			err:   "schema must be between -4 and 8",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:0,zero_threshold:-1,zero_count:0}\n# EOF\n",
			err:   "zero_threshold must be a non-negative, finite number",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:0,zero_threshold:NaN,zero_count:0}\n# EOF\n",
			err:   "zero_threshold must be a non-negative, finite number",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:0,zero_threshold:+Inf,zero_count:0}\n# EOF\n",
			err:   "zero_threshold must be a non-negative, finite number",
		},
		{
			input: "# TYPE foo histogram\nfoo 5\n# EOF\n",
			err:   "composite value required for metric type",
		},
		{
			input: "# TYPE foo gaugehistogram\nfoo 5\n# EOF\n",
			err:   "composite value required for metric type",
		},
		{
			input: "# TYPE foo summary\nfoo 5\n# EOF\n",
			err:   "composite value required for metric type",
		},
		{
			input: "# TYPE foo summary\nfoo {sum:2.0,quantile:[0.5:1.0]}\n# EOF\n",
			err:   "missing required field: count",
		},
		{
			input: "# TYPE foo summary\nfoo {count:1,quantile:[0.5:1.0]}\n# EOF\n",
			err:   "missing required field: sum",
		},
		{
			input: "# TYPE foo summary\nfoo {count:1,sum:2.0}\n# EOF\n",
			err:   "missing required field: quantile",
		},
		{
			input: "# TYPE foo histogram\nfoo {sum:2.0,bucket:[+Inf:1]}\n# EOF\n",
			err:   "missing required field: count",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,bucket:[+Inf:1]}\n# EOF\n",
			err:   "missing required field: sum",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:2.0}\n# EOF\n",
			err:   "missing required field: bucket",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:2.0,bucket:[0.1:1]}\n# EOF\n",
			err:   "classic histogram buckets must include a +Inf threshold",
		},
		{
			input: "# TYPE ss stateset\nss{ss=\"foo\"} 2\n# EOF\n",
			err:   "stateset sample value must be 0 or 1",
		},
		{
			input: "# TYPE ss stateset\nss{other=\"foo\"} 1\n# EOF\n",
			err:   "stateset sample must have a label matching the metric family name",
		},
		{
			input: "# TYPE foo_total counter\nfoo_total NaN\n# EOF\n",
			err:   "counter sample value must not be NaN",
		},
		{
			// A NaN sum relaxes the Validate check to "count is at least the
			// bucket total", so the wrapped count was accepted as 18446744073709551615.
			input: "# TYPE foo histogram\nfoo {count:-1,sum:NaN,schema:0,zero_threshold:0,zero_count:0,positive_spans:[0:2],positive_buckets:[2,1]}\n# EOF\n",
			err:   "count must not be negative",
		},
		{
			// A gauge histogram takes the same integer path, and no histogram type
			// can hold a negative count, so gcount is checked too.
			input: "# TYPE foo gaugehistogram\nfoo {gcount:-1,gsum:NaN,schema:0,zero_threshold:0,zero_count:0,positive_spans:[0:2],positive_buckets:[2,1]}\n# EOF\n",
			err:   "gcount must not be negative",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:1,sum:1.0,schema:0,zero_threshold:0,zero_count:-1}\n# EOF\n",
			err:   "zero_count must not be negative",
		},
		{
			// Histogram bucket values are counters, so they must not be negative.
			input: "# TYPE foo histogram\nfoo {count:3,sum:6.0,bucket:[1.0:-1,+Inf:3]}\n# EOF\n",
			err:   "value must not be negative",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:3,sum:6.0,bucket:[abc:1,+Inf:3]}\n# EOF\n",
			err:   "invalid bucket threshold",
		},
		{
			input: "# TYPE foo histogram\nfoo {count:3,sum:6.0,bucket:[NaN:1,+Inf:3]}\n# EOF\n",
			err:   "bucket threshold must not be NaN",
		},
		{
			// -Inf is only permitted as the first threshold.
			input: "# TYPE foo histogram\nfoo {count:3,sum:6.0,bucket:[1.0:1,-Inf:2,+Inf:3]}\n# EOF\n",
			err:   "classic histogram buckets must be sorted in increasing order",
		},
		{
			input: "# TYPE foo summary\nfoo {count:1,sum:2.0,quantile:[abc:1.0]}\n# EOF\n",
			err:   "invalid quantile",
		},
		{
			input: "# TYPE foo summary\nfoo {count:1,sum:2.0,quantile:[1.5:1.0]}\n# EOF\n",
			err:   "quantile must be between 0.0 and 1.0",
		},
		{
			input: "# TYPE foo summary\nfoo {count:1,sum:2.0,quantile:[NaN:1.0]}\n# EOF\n",
			err:   "quantile must not be NaN",
		},
	} {
		t.Run(tc.err, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(tc.input), labels.NewSymbolTable(), ParserOptions{})
			var gotErr error
			for {
				_, err := p.Next()
				if err != nil {
					gotErr = err
					break
				}
			}
			require.ErrorContains(t, gotErr, tc.err)
		})
	}
}

// TestOpenMetrics2ParseHistogramNativeDetectionRequiresSchema verifies that a
// composite carrying zero_threshold/zero_count but no schema must fall through
// to classic histogram parsing instead of failing with "missing required field: schema".
func TestOpenMetrics2ParseHistogramNativeDetectionRequiresSchema(t *testing.T) {
	input := `# TYPE foo histogram
foo {count:1,sum:1.0,zero_threshold:0,zero_count:0,bucket:[+Inf:1]}
# EOF
`
	exp := []parsedEntry{
		{m: "foo", typ: model.MetricTypeHistogram},
		{
			m:    "foo_count",
			v:    1,
			lset: labels.FromStrings("__name__", "foo_count"),
		},
		{
			m:    "foo_sum",
			v:    1.0,
			lset: labels.FromStrings("__name__", "foo_sum"),
		},
		{
			m:    "foo_bucket\xffle\xff+Inf",
			v:    1,
			lset: labels.FromStrings("__name__", "foo_bucket", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseEOFHandling verifies that the parser returns io.EOF
// correctly when the input ends with "# EOF\n".
func TestOpenMetrics2ParseEOFHandling(t *testing.T) {
	p := NewOpenMetrics2Parser([]byte("# EOF\n"), labels.NewSymbolTable(), ParserOptions{})
	et, err := p.Next()
	require.Equal(t, EntryInvalid, et)
	require.ErrorIs(t, err, io.EOF)
}

func TestOpenMetrics2ParseCompositeExtraLabelsUTF8(t *testing.T) {
	input := `# TYPE "req.duration" histogram
{"req.duration",job="api"} {count:3,sum:6.0,bucket:[0.1:1,+Inf:3]}
# EOF
`
	exp := []parsedEntry{
		{m: "req.duration", typ: model.MetricTypeHistogram},
		{
			m:    "req.duration_count\xffjob\xffapi",
			v:    3,
			lset: labels.FromStrings("__name__", "req.duration_count", "job", "api"),
		},
		{
			m:    "req.duration_sum\xffjob\xffapi",
			v:    6.0,
			lset: labels.FromStrings("__name__", "req.duration_sum", "job", "api"),
		},
		{
			m:    "req.duration_bucket\xffjob\xffapi\xffle\xff0.1",
			v:    1,
			lset: labels.FromStrings("__name__", "req.duration_bucket", "job", "api", "le", "0.1"),
		},
		{
			m:    "req.duration_bucket\xffjob\xffapi\xffle\xff+Inf",
			v:    3,
			lset: labels.FromStrings("__name__", "req.duration_bucket", "job", "api", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseCompositeExtraLabels(t *testing.T) {
	input := `# TYPE req_duration histogram
req_duration{job="api",env="prod"} {count:3,sum:6.0,bucket:[0.1:1,1.0:2,+Inf:3]}
# EOF
`
	exp := []parsedEntry{
		{m: "req_duration", typ: model.MetricTypeHistogram},
		{
			m:    "req_duration_count\xffenv\xffprod\xffjob\xffapi",
			v:    3,
			lset: labels.FromStrings("__name__", "req_duration_count", "env", "prod", "job", "api"),
		},
		{
			m:    "req_duration_sum\xffenv\xffprod\xffjob\xffapi",
			v:    6.0,
			lset: labels.FromStrings("__name__", "req_duration_sum", "env", "prod", "job", "api"),
		},
		{
			m:    "req_duration_bucket\xffenv\xffprod\xffjob\xffapi\xffle\xff0.1",
			v:    1,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "env", "prod", "job", "api", "le", "0.1"),
		},
		{
			m:    "req_duration_bucket\xffenv\xffprod\xffjob\xffapi\xffle\xff1.0",
			v:    2,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "env", "prod", "job", "api", "le", "1.0"),
		},
		{
			m:    "req_duration_bucket\xffenv\xffprod\xffjob\xffapi\xffle\xff+Inf",
			v:    3,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "env", "prod", "job", "api", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseCompositeExtraLabelsQuoted verifies that a quoted
// extra label (OM2 UTF-8 label names) on a composite line is extracted
// correctly — same as it already is on a plain (non-composite) sample line.
func TestOpenMetrics2ParseCompositeExtraLabelsQuoted(t *testing.T) {
	input := `# TYPE foo summary
foo{"user.id"="x"} {count:1,sum:2.0,quantile:[0.5:1.0]}
# EOF
`
	exp := []parsedEntry{
		{m: "foo", typ: model.MetricTypeSummary},
		{
			m:    "foo_count\xffuser.id\xffx",
			v:    1,
			lset: labels.FromStrings("__name__", "foo_count", "user.id", "x"),
		},
		{
			m:    "foo_sum\xffuser.id\xffx",
			v:    2.0,
			lset: labels.FromStrings("__name__", "foo_sum", "user.id", "x"),
		},
		{
			m:    "foo\xffquantile\xff0.5\xffuser.id\xffx",
			v:    1.0,
			lset: labels.FromStrings("__name__", "foo", "quantile", "0.5", "user.id", "x"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseCompositeExtraLabelsQuotedWithEquals verifies that a
// quoted extra label whose name itself contains "=" (valid per the OM2
// UTF-8 label-name grammar) doesn't confuse the key/value split for a
// composite line's extra labels.
func TestOpenMetrics2ParseCompositeExtraLabelsQuotedWithEquals(t *testing.T) {
	input := `# TYPE foo summary
foo{"a=b"="v",job="api"} {count:1,sum:2.0,quantile:[0.5:1.0]}
# EOF
`
	exp := []parsedEntry{
		{m: "foo", typ: model.MetricTypeSummary},
		{
			m:    "foo_count\xffa=b\xffv\xffjob\xffapi",
			v:    1,
			lset: labels.FromStrings("__name__", "foo_count", "a=b", "v", "job", "api"),
		},
		{
			m:    "foo_sum\xffa=b\xffv\xffjob\xffapi",
			v:    2.0,
			lset: labels.FromStrings("__name__", "foo_sum", "a=b", "v", "job", "api"),
		},
		{
			m:    "foo\xffa=b\xffv\xffjob\xffapi\xffquantile\xff0.5",
			v:    1.0,
			lset: labels.FromStrings("__name__", "foo", "a=b", "v", "job", "api", "quantile", "0.5"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseCompositeSeriesUnique checks that Series() never
// returns the same bytes for two entries with different label sets; the
// scrape loop uses those bytes as a cache key, so a collision would corrupt
// or drop samples.
func TestOpenMetrics2ParseCompositeSeriesUnique(t *testing.T) {
	for _, tc := range []struct {
		name  string
		input string
	}{
		{
			name: "classic histogram buckets",
			input: `# TYPE foo histogram
foo {count:5,sum:12.5,bucket:[0.5:1,1:3,+Inf:5]}
# EOF
`,
		},
		{
			name: "classic histogram with differing extra labels",
			input: `# TYPE foo histogram
foo{path="/a"} {count:1,sum:1.0,bucket:[1.0:1,+Inf:1]}
foo{path="/b"} {count:2,sum:2.0,bucket:[1.0:1,+Inf:2]}
# EOF
`,
		},
		{
			name: "summary quantiles",
			input: `# TYPE foo summary
foo {count:5,sum:12.5,quantile:[0.5:1.0,0.9:2.0,0.99:3.0]}
# EOF
`,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(tc.input), labels.NewSymbolTable(), ParserOptions{})
			got := testParse(t, p)

			seen := map[string]labels.Labels{}
			for _, e := range got {
				if prev, ok := seen[e.m]; ok {
					require.Truef(t, labels.Equal(prev, e.lset),
						"series key %q reused for a different label set: first saw %s, now %s", e.m, prev, e.lset)
				}
				seen[e.m] = e.lset
			}
		})
	}
}

func TestOpenMetrics2ParseCompositeWithTimestamp(t *testing.T) {
	input := `# TYPE req_duration histogram
req_duration {count:2,sum:4.0,bucket:[+Inf:2]} 1234567.0 st@1000.0
# EOF
`
	exp := []parsedEntry{
		{m: "req_duration", typ: model.MetricTypeHistogram},
		{
			m:    "req_duration_count",
			v:    2,
			t:    int64p(1234567000),
			st:   1000000,
			lset: labels.FromStrings("__name__", "req_duration_count"),
		},
		{
			m:    "req_duration_sum",
			v:    4.0,
			t:    int64p(1234567000),
			st:   1000000,
			lset: labels.FromStrings("__name__", "req_duration_sum"),
		},
		{
			m:    "req_duration_bucket\xffle\xff+Inf",
			v:    2,
			t:    int64p(1234567000),
			st:   1000000,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseFloatHistogram(t *testing.T) {
	input := `# TYPE test_histogram histogram
test_histogram {count:5.5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2.5,negative_spans:[],negative_buckets:[],positive_spans:[0:2],positive_buckets:[2.0,1.0]}
# EOF
`
	exp := []parsedEntry{
		{m: "test_histogram", typ: model.MetricTypeHistogram},
		{
			m:    "test_histogram",
			lset: labels.FromStrings("__name__", "test_histogram"),
			fhs: &histogram.FloatHistogram{
				Schema:          0,
				ZeroThreshold:   0.001,
				ZeroCount:       2.5,
				Count:           5.5,
				Sum:             12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2.0, 1.0},
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseNativeHistogramIntVsFloatDiscriminator covers each input
// that can flip the parser between *histogram.Histogram and *histogram.FloatHistogram.
// Per the OM2 spec a native histogram is integer only if count, zero_count, and
// every bucket value are integers; any fractional value anywhere makes it a
// FloatHistogram. sum is float64 in both kinds and must not discriminate.
func TestOpenMetrics2ParseNativeHistogramIntVsFloatDiscriminator(t *testing.T) {
	for _, tc := range []struct {
		name  string
		input string
		shs   *histogram.Histogram
		fhs   *histogram.FloatHistogram
	}{
		{
			name:  "all integer fields -> Histogram",
			input: `h {count:5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[2,1]}`,
			shs: &histogram.Histogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 5, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []int64{2, -1},
			},
		},
		{
			name:  "fractional count -> FloatHistogram",
			input: `h {count:5.5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[2,1]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 5.5, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2, 1},
			},
		},
		{
			name:  "fractional zero_count -> FloatHistogram",
			input: `h {count:5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2.5,positive_spans:[0:2],positive_buckets:[2,1]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2.5, Count: 5, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2, 1},
			},
		},
		{
			name:  "fractional positive bucket -> FloatHistogram",
			input: `h {count:5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[2.0,1.0]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 5, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2.0, 1.0},
			},
		},
		{
			name:  "fractional negative bucket -> FloatHistogram",
			input: `h {count:5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,negative_spans:[0:2],negative_buckets:[2.0,1.0]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 5, Sum: 12.1,
				NegativeSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				NegativeBuckets: []float64{2.0, 1.0},
			},
		},
		{
			name:  "exponent notation in bucket -> FloatHistogram",
			input: `h {count:5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[1e2,1]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 5, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{1e2, 1},
			},
		},
		{
			name:  "count with no uint64 representation -> FloatHistogram",
			input: `h {count:1e20,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[2,1]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 1e20, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2, 1},
			},
		},
		{
			name:  "infinite count -> FloatHistogram",
			input: `h {count:+Inf,sum:12.1,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[2,1]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: math.Inf(1), Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2, 1},
			},
		},
		{
			name:  "zero_count with no uint64 representation -> FloatHistogram",
			input: `h {count:5,sum:12.1,schema:0,zero_threshold:0.001,zero_count:1e20,positive_spans:[0:2],positive_buckets:[2,1]}`,
			fhs: &histogram.FloatHistogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 1e20, Count: 5, Sum: 12.1,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []float64{2, 1},
			},
		},
		{
			name:  "fractional sum only -> Histogram (sum does not discriminate)",
			input: `h {count:5,sum:12.5,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[2,1]}`,
			shs: &histogram.Histogram{
				Schema: 0, ZeroThreshold: 0.001, ZeroCount: 2, Count: 5, Sum: 12.5,
				PositiveSpans:   []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets: []int64{2, -1},
			},
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			input := "# TYPE h histogram\n" + tc.input + "\n# EOF\n"
			exp := []parsedEntry{
				{m: "h", typ: model.MetricTypeHistogram},
				{
					m:    "h",
					lset: labels.FromStrings("__name__", "h"),
					shs:  tc.shs,
					fhs:  tc.fhs,
				},
			}
			p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
			got := testParse(t, p)
			requireEntries(t, exp, got)
		})
	}
}

func TestOpenMetrics2ParseCompositeGaugeHistogram(t *testing.T) {
	input := `# TYPE req_size gaugehistogram
req_size {gcount:6,gsum:100.0,schema:0,zero_threshold:0.001,zero_count:1,negative_spans:[],negative_buckets:[],positive_spans:[0:2],positive_buckets:[3,2]}
# EOF
`
	exp := []parsedEntry{
		{m: "req_size", typ: model.MetricTypeGaugeHistogram},
		{
			m:    "req_size",
			lset: labels.FromStrings("__name__", "req_size"),
			shs: &histogram.Histogram{
				Schema:           0,
				ZeroThreshold:    0.001,
				ZeroCount:        1,
				Count:            6,
				Sum:              100.0,
				PositiveSpans:    []histogram.Span{{Offset: 0, Length: 2}},
				PositiveBuckets:  []int64{3, -1},
				CounterResetHint: histogram.GaugeType,
			},
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseTypeAndUnitLabels(t *testing.T) {
	input := `# TYPE process_open_fds gauge
# UNIT process_open_fds fds
process_open_fds 8.0
# TYPE rpc_duration_seconds summary
# UNIT rpc_duration_seconds seconds
rpc_duration_seconds {count:10,sum:5.0,quantile:[0.5:1.0]}
# EOF
`
	exp := []parsedEntry{
		{m: "process_open_fds", typ: model.MetricTypeGauge},
		{m: "process_open_fds", unit: "fds"},
		{
			m:    "process_open_fds",
			v:    8.0,
			lset: labels.FromStrings("__name__", "process_open_fds", "__type__", "gauge", "__unit__", "fds"),
		},
		{m: "rpc_duration_seconds", typ: model.MetricTypeSummary},
		{m: "rpc_duration_seconds", unit: "seconds"},
		{
			m:    "rpc_duration_seconds_count\xff__type__\xffsummary\xff__unit__\xffseconds",
			v:    10,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds_count", "__type__", "summary", "__unit__", "seconds"),
		},
		{
			m:    "rpc_duration_seconds_sum\xff__type__\xffsummary\xff__unit__\xffseconds",
			v:    5.0,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds_sum", "__type__", "summary", "__unit__", "seconds"),
		},
		{
			m:    "rpc_duration_seconds\xff__type__\xffsummary\xff__unit__\xffseconds\xffquantile\xff0.5",
			v:    1.0,
			lset: labels.FromStrings("__name__", "rpc_duration_seconds", "__type__", "summary", "__unit__", "seconds", "quantile", "0.5"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseTypeAndUnitLabelsScalarTypes(t *testing.T) {
	input := `# TYPE http_requests_total counter
# UNIT http_requests_total requests
http_requests_total{method="get"} 5.0
# TYPE build_info info
build_info{version="1.0"} 1.0
# TYPE subsystem_enabled stateset
subsystem_enabled{subsystem_enabled="auth"} 0.0
# TYPE unknown_metric unknown
unknown_metric 42.0
# EOF
`
	exp := []parsedEntry{
		{m: "http_requests_total", typ: model.MetricTypeCounter},
		{m: "http_requests_total", unit: "requests"},
		{
			m:    `http_requests_total{method="get"}`,
			v:    5.0,
			lset: labels.FromStrings("__name__", "http_requests_total", "__type__", "counter", "__unit__", "requests", "method", "get"),
		},
		{m: "build_info", typ: model.MetricTypeInfo},
		{
			m:    `build_info{version="1.0"}`,
			v:    1.0,
			lset: labels.FromStrings("__name__", "build_info", "__type__", "info", "version", "1.0"),
		},
		{m: "subsystem_enabled", typ: model.MetricTypeStateset},
		{
			m:    `subsystem_enabled{subsystem_enabled="auth"}`,
			v:    0.0,
			lset: labels.FromStrings("__name__", "subsystem_enabled", "__type__", "stateset", "subsystem_enabled", "auth"),
		},
		{m: "unknown_metric", typ: model.MetricTypeUnknown},
		{
			m:    "unknown_metric",
			v:    42.0,
			lset: labels.FromStrings("__name__", "unknown_metric"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseTypeAndUnitLabelsClassicHistogram(t *testing.T) {
	input := `# TYPE http_request_duration_seconds histogram
# UNIT http_request_duration_seconds seconds
http_request_duration_seconds {count:3,sum:6.0,bucket:[0.1:1,0.5:2,+Inf:3]}
# EOF
`
	exp := []parsedEntry{
		{m: "http_request_duration_seconds", typ: model.MetricTypeHistogram},
		{m: "http_request_duration_seconds", unit: "seconds"},
		{
			m:    "http_request_duration_seconds_count\xff__type__\xffhistogram\xff__unit__\xffseconds",
			v:    3,
			lset: labels.FromStrings("__name__", "http_request_duration_seconds_count", "__type__", "histogram", "__unit__", "seconds"),
		},
		{
			m:    "http_request_duration_seconds_sum\xff__type__\xffhistogram\xff__unit__\xffseconds",
			v:    6.0,
			lset: labels.FromStrings("__name__", "http_request_duration_seconds_sum", "__type__", "histogram", "__unit__", "seconds"),
		},
		{
			m:    "http_request_duration_seconds_bucket\xff__type__\xffhistogram\xff__unit__\xffseconds\xffle\xff0.1",
			v:    1,
			lset: labels.FromStrings("__name__", "http_request_duration_seconds_bucket", "__type__", "histogram", "__unit__", "seconds", "le", "0.1"),
		},
		{
			m:    "http_request_duration_seconds_bucket\xff__type__\xffhistogram\xff__unit__\xffseconds\xffle\xff0.5",
			v:    2,
			lset: labels.FromStrings("__name__", "http_request_duration_seconds_bucket", "__type__", "histogram", "__unit__", "seconds", "le", "0.5"),
		},
		{
			m:    "http_request_duration_seconds_bucket\xff__type__\xffhistogram\xff__unit__\xffseconds\xffle\xff+Inf",
			v:    3,
			lset: labels.FromStrings("__name__", "http_request_duration_seconds_bucket", "__type__", "histogram", "__unit__", "seconds", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseTypeAndUnitLabelsGaugeHistogram(t *testing.T) {
	input := `# TYPE response_size_bytes gaugehistogram
# UNIT response_size_bytes bytes
response_size_bytes {gcount:4,gsum:1024.0,bucket:[100:1,500:3,+Inf:4]}
# EOF
`
	exp := []parsedEntry{
		{m: "response_size_bytes", typ: model.MetricTypeGaugeHistogram},
		{m: "response_size_bytes", unit: "bytes"},
		{
			m:    "response_size_bytes_gcount\xff__type__\xffgaugehistogram\xff__unit__\xffbytes",
			v:    4,
			lset: labels.FromStrings("__name__", "response_size_bytes_gcount", "__type__", "gaugehistogram", "__unit__", "bytes"),
		},
		{
			m:    "response_size_bytes_gsum\xff__type__\xffgaugehistogram\xff__unit__\xffbytes",
			v:    1024.0,
			lset: labels.FromStrings("__name__", "response_size_bytes_gsum", "__type__", "gaugehistogram", "__unit__", "bytes"),
		},
		{
			m:    "response_size_bytes_bucket\xff__type__\xffgaugehistogram\xff__unit__\xffbytes\xffle\xff100.0",
			v:    1,
			lset: labels.FromStrings("__name__", "response_size_bytes_bucket", "__type__", "gaugehistogram", "__unit__", "bytes", "le", "100.0"),
		},
		{
			m:    "response_size_bytes_bucket\xff__type__\xffgaugehistogram\xff__unit__\xffbytes\xffle\xff500.0",
			v:    3,
			lset: labels.FromStrings("__name__", "response_size_bytes_bucket", "__type__", "gaugehistogram", "__unit__", "bytes", "le", "500.0"),
		},
		{
			m:    "response_size_bytes_bucket\xff__type__\xffgaugehistogram\xff__unit__\xffbytes\xffle\xff+Inf",
			v:    4,
			lset: labels.FromStrings("__name__", "response_size_bytes_bucket", "__type__", "gaugehistogram", "__unit__", "bytes", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

// TestOpenMetrics2ParseUnsortedClassicBucketsRejected verifies that classic
// histogram buckets out of increasing order are rejected: the spec requires
// "Classic Buckets MUST be sorted in number increasing order".
// https://prometheus.io/docs/specs/om/open_metrics_spec_2_0/#histogram-with-classic-buckets
func TestOpenMetrics2ParseUnsortedClassicBucketsRejected(t *testing.T) {
	input := `# TYPE req_duration histogram
req_duration {count:144,sum:53.4,bucket:[+Inf:144,0.1:24,0.2:33,0.4:100,1.0:144]}
# EOF
`
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	var gotErr error
	for {
		_, err := p.Next()
		if err != nil {
			gotErr = err
			break
		}
	}
	require.ErrorContains(t, gotErr, "classic histogram buckets must be sorted in increasing order")
}

func TestOpenMetrics2ParseExemplarOnCompositeLine(t *testing.T) {
	input := `# TYPE req_duration histogram
req_duration {count:2,sum:4.0,bucket:[1.0:1,+Inf:2]} # {id="req-1"} 3.8 9999999.0
# EOF
`
	exp := []parsedEntry{
		{m: "req_duration", typ: model.MetricTypeHistogram},
		// Exemplar is accessible only on the first pending entry served.
		{
			m:    "req_duration_count",
			v:    2,
			lset: labels.FromStrings("__name__", "req_duration_count"),
			es:   []exemplar.Exemplar{{Labels: labels.FromStrings("id", "req-1"), Value: 3.8, HasTs: true, Ts: 9999999000}},
		},
		{
			m:    "req_duration_sum",
			v:    4.0,
			lset: labels.FromStrings("__name__", "req_duration_sum"),
		},
		{
			m:    "req_duration_bucket\xffle\xff1.0",
			v:    1,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "1.0"),
		},
		{
			m:    "req_duration_bucket\xffle\xff+Inf",
			v:    2,
			lset: labels.FromStrings("__name__", "req_duration_bucket", "le", "+Inf"),
		},
	}

	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseDescriptorOrderTypeBeforeHelp(t *testing.T) {
	// TYPE before HELP (and UNIT after HELP) must not corrupt the parsed type or unit.
	input := `# TYPE open_fds gauge
# HELP open_fds Number of open file descriptors.
# UNIT open_fds fds
open_fds 8.0
# EOF
`
	exp := []parsedEntry{
		{m: "open_fds", typ: model.MetricTypeGauge},
		{m: "open_fds", help: "Number of open file descriptors."},
		{m: "open_fds", unit: "fds"},
		{
			m:    "open_fds",
			v:    8.0,
			lset: labels.FromStrings("__name__", "open_fds", "__type__", "gauge", "__unit__", "fds"),
		},
	}
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseDescriptorOrderUnitBeforeType(t *testing.T) {
	// UNIT before TYPE: p.unit must not be erased by the p.unit="" reset in tType.
	input := `# UNIT http_requests requests
# TYPE http_requests counter
http_requests 1.0
# EOF
`
	exp := []parsedEntry{
		{m: "http_requests", unit: "requests"},
		{m: "http_requests", typ: model.MetricTypeCounter},
		{
			m:    "http_requests",
			v:    1.0,
			lset: labels.FromStrings("__name__", "http_requests", "__type__", "counter", "__unit__", "requests"),
		},
	}
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseFamilyResetOnUndeclaredMetric(t *testing.T) {
	// A metric family with no descriptor lines at all must not inherit
	// mtype/unit from the previous family
	input := `# TYPE http_requests counter
# UNIT http_requests requests
http_requests 1.0
bare_metric 2.0
# EOF
`
	exp := []parsedEntry{
		{m: "http_requests", typ: model.MetricTypeCounter},
		{m: "http_requests", unit: "requests"},
		{
			m:    "http_requests",
			v:    1.0,
			lset: labels.FromStrings("__name__", "http_requests", "__type__", "counter", "__unit__", "requests"),
		},
		{
			m:    "bare_metric",
			v:    2.0,
			lset: labels.FromStrings("__name__", "bare_metric"),
		},
	}
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
	got := testParse(t, p)
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseFamilyResetOnSuffixedMetric(t *testing.T) {
	// OM2 removes the implicit suffix stripping of OM1: a Metric name must
	// exactly match its MetricFamily name. A sample whose name only
	// suffix-extends the declared family (e.g. foo_total under `# TYPE foo`)
	// does not belong to that family and is parsed as untyped, whereas a
	// sample whose name matches the descriptor exactly keeps the declared type.
	for _, tc := range []struct {
		name  string
		input string
		exp   []parsedEntry
	}{
		{
			name: "suffix mismatch reverts to unknown",
			input: `# TYPE foo counter
foo_total 1.0
# EOF
`,
			exp: []parsedEntry{
				{m: "foo", typ: model.MetricTypeCounter},
				{
					m:    "foo_total",
					v:    1.0,
					lset: labels.FromStrings("__name__", "foo_total"),
				},
			},
		},
		{
			name: "exact match keeps counter type",
			input: `# TYPE foo_total counter
foo_total 1.0
# EOF
`,
			exp: []parsedEntry{
				{m: "foo_total", typ: model.MetricTypeCounter},
				{
					m:    "foo_total",
					v:    1.0,
					lset: labels.FromStrings("__name__", "foo_total", "__type__", "counter"),
				},
			},
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(tc.input), labels.NewSymbolTable(), ParserOptions{EnableTypeAndUnitLabels: true})
			got := testParse(t, p)
			requireEntries(t, tc.exp, got)
		})
	}
}

func TestOpenMetrics2ParseExemplarEscapedLabelNamesAndNullBytes(t *testing.T) {
	input := "foo_total 1.0 1700000000.0 # {\"trace\\\\id\\n\\\"1\\\"\"=\"a\x00b\\nc\"} 1.0 1700000000.5\n# EOF\n"
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	exp := []parsedEntry{
		{
			m:    "foo_total",
			v:    1.0,
			t:    int64p(1700000000000),
			lset: labels.FromStrings("__name__", "foo_total"),
			es: []exemplar.Exemplar{
				{
					Labels: labels.FromStrings("trace\\id\n\"1\"", "a\x00b\nc"),
					Value:  1.0,
					HasTs:  true,
					Ts:     1700000000500,
				},
			},
		},
	}
	requireEntries(t, exp, got)
}

func TestOpenMetrics2ParseIgnoreNativeHistograms(t *testing.T) {
	t.Run("native-only histogram emits count sum and +Inf bucket", func(t *testing.T) {
		input := `# TYPE req_seconds histogram
req_seconds{service="api"} {count:12,sum:5.5,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[3,7]} 1700000000.0
# EOF
`
		p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{
			IgnoreNativeHistograms: true,
		})
		got := testParse(t, p)
		exp := []parsedEntry{
			{m: "req_seconds", typ: model.MetricTypeHistogram},
			{
				m:    "req_seconds_count\xffservice\xffapi",
				v:    12,
				t:    int64p(1700000000000),
				lset: labels.FromStrings("__name__", "req_seconds_count", "service", "api"),
			},
			{
				m:    "req_seconds_sum\xffservice\xffapi",
				v:    5.5,
				t:    int64p(1700000000000),
				lset: labels.FromStrings("__name__", "req_seconds_sum", "service", "api"),
			},
			{
				m:    "req_seconds_bucket\xffle\xff+Inf\xffservice\xffapi",
				v:    12,
				t:    int64p(1700000000000),
				lset: labels.FromStrings("__name__", "req_seconds_bucket", "le", "+Inf", "service", "api"),
			},
		}
		requireEntries(t, exp, got)
	})

	t.Run("dual classic and native histogram emits classic series only", func(t *testing.T) {
		input := `# TYPE req_seconds histogram
req_seconds {count:12,sum:5.5,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[3,7],bucket:[1.0:3,2.0:7,+Inf:12]}
# EOF
`
		p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{
			IgnoreNativeHistograms: true,
		})
		got := testParse(t, p)
		exp := []parsedEntry{
			{m: "req_seconds", typ: model.MetricTypeHistogram},
			{
				m:    "req_seconds_count",
				v:    12,
				lset: labels.FromStrings("__name__", "req_seconds_count"),
			},
			{
				m:    "req_seconds_sum",
				v:    5.5,
				lset: labels.FromStrings("__name__", "req_seconds_sum"),
			},
			{
				m:    "req_seconds_bucket\xffle\xff1.0",
				v:    3,
				lset: labels.FromStrings("__name__", "req_seconds_bucket", "le", "1.0"),
			},
			{
				m:    "req_seconds_bucket\xffle\xff2.0",
				v:    7,
				lset: labels.FromStrings("__name__", "req_seconds_bucket", "le", "2.0"),
			},
			{
				m:    "req_seconds_bucket\xffle\xff+Inf",
				v:    12,
				lset: labels.FromStrings("__name__", "req_seconds_bucket", "le", "+Inf"),
			},
		}
		requireEntries(t, exp, got)
	})

	t.Run("native-only histogram with NHCB conversion emits single +Inf custom bucket", func(t *testing.T) {
		input := `# TYPE req_seconds histogram
req_seconds{service="api"} {count:12,sum:5.5,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[3,7]} 1700000000.0
# EOF
`
		p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{
			IgnoreNativeHistograms:         true,
			ConvertClassicHistogramsToNHCB: true,
		})
		got := testParse(t, p)
		exp := []parsedEntry{
			{m: "req_seconds", typ: model.MetricTypeHistogram},
			{
				m:    `req_seconds{service="api"}`,
				t:    int64p(1700000000000),
				lset: labels.FromStrings("__name__", "req_seconds", "service", "api"),
				shs: &histogram.Histogram{
					Schema:          histogram.CustomBucketsSchema,
					Count:           12,
					Sum:             5.5,
					PositiveSpans:   []histogram.Span{{Offset: 0, Length: 1}},
					PositiveBuckets: []int64{12},
				},
			},
		}
		requireEntries(t, exp, got)
	})

	t.Run("dual classic and native histogram with native ignored and with NHCB conversion emits NHCB", func(t *testing.T) {
		input := `# TYPE req_seconds histogram
req_seconds {count:12,sum:5.5,schema:0,zero_threshold:0.001,zero_count:2,positive_spans:[0:2],positive_buckets:[3,7],bucket:[1.0:3,2.0:7,+Inf:12]}
# EOF
`
		p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{
			IgnoreNativeHistograms:         true,
			ConvertClassicHistogramsToNHCB: true,
		})
		got := testParse(t, p)
		exp := []parsedEntry{
			{m: "req_seconds", typ: model.MetricTypeHistogram},
			{
				m:    "req_seconds",
				lset: labels.FromStrings("__name__", "req_seconds"),
				shs: &histogram.Histogram{
					Schema:          histogram.CustomBucketsSchema,
					Count:           12,
					Sum:             5.5,
					PositiveSpans:   []histogram.Span{{Offset: 0, Length: 3}},
					PositiveBuckets: []int64{3, 1, 1},
					CustomValues:    []float64{1.0, 2.0},
				},
			},
		}
		requireEntries(t, exp, got)
	})
}

func TestOpenMetrics2ParseSpecValidationErrors(t *testing.T) {
	for _, tc := range []struct {
		name    string
		input   string
		wantErr string
	}{
		{
			name:    "empty quoted label name in sample",
			input:   "foo{\"\"=\"val\"} 1.0\n# EOF\n",
			wantErr: "label name must not be empty",
		},
		{
			name:    "empty quoted label name in exemplar",
			input:   "foo 1.0 # {\"\"=\"val\"} 1.0 1700000000.0\n# EOF\n",
			wantErr: "label name must not be empty",
		},
		{
			name:    "info metric with non-empty unit (TYPE before UNIT)",
			input:   "# TYPE build_info info\n# UNIT build_info seconds\nbuild_info{v=\"1\"} 1\n# EOF\n",
			wantErr: "info metric \"build_info\" must have an empty unit",
		},
		{
			name:    "info metric with non-empty unit (UNIT before TYPE)",
			input:   "# UNIT build_info seconds\n# TYPE build_info info\nbuild_info{v=\"1\"} 1\n# EOF\n",
			wantErr: "info metric \"build_info\" must have an empty unit",
		},
		{
			name:    "stateset metric with non-empty unit (TYPE before UNIT)",
			input:   "# TYPE flags stateset\n# UNIT flags seconds\nflags{flags=\"a\"} 1\n# EOF\n",
			wantErr: "stateset metric \"flags\" must have an empty unit",
		},
		{
			name:    "stateset metric with non-empty unit (UNIT before TYPE)",
			input:   "# UNIT flags seconds\n# TYPE flags stateset\nflags{flags=\"a\"} 1\n# EOF\n",
			wantErr: "stateset metric \"flags\" must have an empty unit",
		},
		{
			name:    "info metric family name missing _info suffix",
			input:   "# TYPE build info\nbuild{v=\"1\"} 1\n# EOF\n",
			wantErr: "info metric family name \"build\" must end with _info",
		},
		{
			name:    "info metric sample value not 1 (zero)",
			input:   "# TYPE build_info info\nbuild_info{v=\"1\"} 0\n# EOF\n",
			wantErr: "info sample value must be 1",
		},
		{
			name:    "info metric sample value not 1 (two)",
			input:   "# TYPE build_info info\nbuild_info{v=\"1\"} 2.0\n# EOF\n",
			wantErr: "info sample value must be 1",
		},
		{
			name:    "carriage return in HELP line",
			input:   "# HELP foo help text\r\nfoo 1.0\n# EOF\n",
			wantErr: "unexpected carriage return",
		},
		{
			name:    "carriage return in TYPE line",
			input:   "# TYPE foo gauge\r\nfoo 1.0\n# EOF\n",
			wantErr: "unexpected carriage return",
		},
		{
			name:    "carriage return in UNIT line",
			input:   "# UNIT foo seconds\r\nfoo 1.0\n# EOF\n",
			wantErr: "unexpected carriage return",
		},
		{
			name:    "carriage return in scalar sample line",
			input:   "foo 1.0\r\n# EOF\n",
			wantErr: "while parsing",
		},
		{
			name:    "carriage return in composite sample line",
			input:   "# TYPE foo histogram\nfoo {count:1,sum:1,bucket:[+Inf:1]}\r\n# EOF\n",
			wantErr: "unexpected carriage return",
		},
		{
			name:    "carriage return in EOF line",
			input:   "foo 1.0\n# EOF\r\n",
			wantErr: "unexpected data after # EOF",
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := NewOpenMetrics2Parser([]byte(tc.input), labels.NewSymbolTable(), ParserOptions{})
			var err error
			for {
				_, err = p.Next()
				if err != nil {
					break
				}
			}
			require.Error(t, err)
			require.NotErrorIs(t, err, io.EOF)
			require.ErrorContains(t, err, tc.wantErr)
		})
	}
}

func TestOpenMetrics2ParseCarriageReturnInHelp(t *testing.T) {
	input := "# HELP foo first\rsecond\nfoo 1\n# EOF\n"
	p := NewOpenMetrics2Parser([]byte(input), labels.NewSymbolTable(), ParserOptions{})
	got := testParse(t, p)
	exp := []parsedEntry{
		{
			m:    "foo",
			help: "first\rsecond",
		},
		{
			m:    "foo",
			v:    1,
			lset: labels.FromStrings("__name__", "foo"),
		},
	}
	requireEntries(t, exp, got)
}
