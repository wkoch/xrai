// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package aws

import (
	"context"
	"fmt"
	"slices"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticache"
	"github.com/aws/aws-sdk-go-v2/service/elasticache/types"
	"github.com/prometheus/common/model"
	"github.com/prometheus/common/promslog"
	"github.com/stretchr/testify/require"

	"github.com/prometheus/prometheus/discovery/targetgroup"
)

// Struct for test data.
type elasticacheDataStore struct {
	region           string
	serverlessCaches []types.ServerlessCache
	cacheClusters    []types.CacheCluster
	tags             map[string][]types.Tag // keyed by cache ARN
}

func TestElasticacheDiscoveryDescribeServerlessCaches(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	for _, tt := range []struct {
		name          string
		ecData        *elasticacheDataStore
		cacheNames    []string
		expectedCount int
	}{
		{
			name: "MultipleCaches",
			ecData: &elasticacheDataStore{
				region: "us-west-2",
				serverlessCaches: []types.ServerlessCache{
					{
						ServerlessCacheName: strptr("test-cache"),
						ARN:                 strptr("arn:aws:elasticache:us-west-2:123456789012:serverlesscache:test-cache"),
						Status:              strptr("available"),
						Engine:              strptr("redis"),
						FullEngineVersion:   strptr("7.1"),
						CreateTime:          aws.Time(time.Now()),
						Endpoint: &types.Endpoint{
							Address: strptr("test-cache.serverless.use1.cache.amazonaws.com"),
							Port:    aws.Int32(6379),
						},
					},
					{
						ServerlessCacheName: strptr("prod-cache"),
						ARN:                 strptr("arn:aws:elasticache:us-west-2:123456789012:serverlesscache:prod-cache"),
						Status:              strptr("available"),
						Engine:              strptr("valkey"),
						FullEngineVersion:   strptr("7.2"),
						CreateTime:          aws.Time(time.Now()),
						Endpoint: &types.Endpoint{
							Address: strptr("prod-cache.serverless.use1.cache.amazonaws.com"),
							Port:    aws.Int32(6379),
						},
					},
				},
			},
			cacheNames:    []string{},
			expectedCount: 2,
		},
		{
			name: "SingleCache",
			ecData: &elasticacheDataStore{
				region: "us-east-1",
				serverlessCaches: []types.ServerlessCache{
					{
						ServerlessCacheName: strptr("single-cache"),
						ARN:                 strptr("arn:aws:elasticache:us-east-1:123456789012:serverlesscache:single-cache"),
						Status:              strptr("available"),
						Engine:              strptr("redis"),
						FullEngineVersion:   strptr("7.1"),
						CreateTime:          aws.Time(time.Now()),
					},
				},
			},
			cacheNames:    []string{"single-cache"},
			expectedCount: 1,
		},
		{
			name: "NoCaches",
			ecData: &elasticacheDataStore{
				region:           "us-east-1",
				serverlessCaches: []types.ServerlessCache{},
			},
			cacheNames:    []string{},
			expectedCount: 0,
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			client := newMockElasticacheClient(tt.ecData)

			d := &ElasticacheDiscovery{
				elasticacheClient: client,
				cfg: &ElasticacheSDConfig{
					Region:             tt.ecData.region,
					RequestConcurrency: 10,
				},
			}

			caches, err := d.describeServerlessCaches(ctx, tt.cacheNames)
			require.NoError(t, err)
			require.Len(t, caches, tt.expectedCount)
		})
	}
}

func TestElasticacheDiscoveryDescribeCacheClusters(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	for _, tt := range []struct {
		name          string
		ecData        *elasticacheDataStore
		clusterIDs    []string
		expectedCount int
		skipTest      bool
	}{
		{
			name: "MockValidation",
			ecData: &elasticacheDataStore{
				region: "us-west-2",
				cacheClusters: []types.CacheCluster{
					{
						CacheClusterId:     strptr("test-cluster-001"),
						ARN:                strptr("arn:aws:elasticache:us-west-2:123456789012:cluster:test-cluster-001"),
						CacheClusterStatus: strptr("available"),
						Engine:             strptr("redis"),
						EngineVersion:      strptr("7.1"),
						CacheNodeType:      strptr("cache.t3.micro"),
						NumCacheNodes:      aws.Int32(1),
						ConfigurationEndpoint: &types.Endpoint{
							Address: strptr("test-cluster.abc123.cfg.use1.cache.amazonaws.com"),
							Port:    aws.Int32(6379),
						},
					},
				},
			},
			clusterIDs:    []string{},
			expectedCount: 1,
			skipTest:      false,
		},
		{
			name: "NoClusters",
			ecData: &elasticacheDataStore{
				region:        "us-east-1",
				cacheClusters: []types.CacheCluster{},
			},
			clusterIDs:    []string{},
			expectedCount: 0,
			skipTest:      false,
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			if tt.skipTest {
				t.Skip("Skipping complex test with concurrency")
			}
			client := newMockElasticacheClient(tt.ecData)

			// Verify mock returns expected data
			output, err := client.DescribeCacheClusters(ctx, &elasticache.DescribeCacheClustersInput{})
			require.NoError(t, err)
			require.Len(t, output.CacheClusters, tt.expectedCount)
		})
	}
}

func TestAddServerlessCacheTargets(t *testing.T) {
	t.Parallel()
	testTime := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	tests := []struct {
		name           string
		cache          *types.ServerlessCache
		tags           []types.Tag
		expectedLabels model.LabelSet
	}{
		{
			name: "ServerlessCacheWithEndpoint",
			cache: &types.ServerlessCache{
				ServerlessCacheName: strptr("my-cache"),
				ARN:                 strptr("arn:aws:elasticache:us-east-1:123456789012:serverlesscache:my-cache"),
				Status:              strptr("available"),
				Engine:              strptr("redis"),
				FullEngineVersion:   strptr("7.1"),
				MajorEngineVersion:  strptr("7"),
				CreateTime:          aws.Time(testTime),
				Endpoint: &types.Endpoint{
					Address: strptr("my-cache.serverless.use1.cache.amazonaws.com"),
					Port:    aws.Int32(6379),
				},
				ReaderEndpoint: &types.Endpoint{
					Address: strptr("my-cache-ro.serverless.use1.cache.amazonaws.com"),
					Port:    aws.Int32(6379),
				},
				SecurityGroupIds: []string{"sg-12345"},
				SubnetIds:        []string{"subnet-abcdef"},
				CacheUsageLimits: &types.CacheUsageLimits{
					DataStorage: &types.DataStorage{
						Maximum: aws.Int32(10),
						Minimum: aws.Int32(1),
						Unit:    types.DataStorageUnitGb,
					},
					ECPUPerSecond: &types.ECPUPerSecond{
						Maximum: aws.Int32(5000),
						Minimum: aws.Int32(1000),
					},
				},
			},
			tags: []types.Tag{
				{Key: strptr("Environment"), Value: strptr("test")},
			},
			expectedLabels: model.LabelSet{
				"__meta_elasticache_deployment_option":                     "serverless",
				"__meta_elasticache_serverless_cache_arn":                  "arn:aws:elasticache:us-east-1:123456789012:serverlesscache:my-cache",
				"__meta_elasticache_serverless_cache_name":                 "my-cache",
				"__meta_elasticache_serverless_cache_status":               "available",
				"__meta_elasticache_serverless_cache_engine":               "redis",
				"__meta_elasticache_serverless_cache_full_engine_version":  "7.1",
				"__meta_elasticache_serverless_cache_major_engine_version": "7",
				"__meta_elasticache_serverless_cache_create_time":          "2024-01-01T00:00:00Z",
				"__meta_elasticache_serverless_cache_endpoint_address":     "my-cache.serverless.use1.cache.amazonaws.com",
				"__meta_elasticache_serverless_cache_endpoint_port":        "6379",

				"__meta_elasticache_serverless_cache_security_group_id_0": "sg-12345",
				"__meta_elasticache_serverless_cache_subnet_id_0":         "subnet-abcdef",

				"__address__": "my-cache.serverless.use1.cache.amazonaws.com:6379",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tg := &targetgroup.Group{
				Source: "test",
			}

			addServerlessCacheTargets(tg, tt.cache, tt.tags)

			require.Len(t, tg.Targets, 1)
			labels := tg.Targets[0]

			// Check that all expected labels are present with correct values
			for k, v := range tt.expectedLabels {
				actualValue, exists := labels[k]
				require.True(t, exists, "label %s should exist", k)
				require.Equal(t, v, actualValue, "label %s mismatch", k)
			}
		})
	}
}

func TestAddCacheClusterTargets(t *testing.T) {
	t.Parallel()
	testTime := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	tests := []struct {
		name                string
		cluster             *types.CacheCluster
		tags                []types.Tag
		expectedTargetCount int
		expectedLabels      []model.LabelSet // One per node
	}{
		{
			name: "CacheClusterWithMultipleNodes",
			cluster: &types.CacheCluster{
				CacheClusterId:         strptr("my-cluster-001"),
				ARN:                    strptr("arn:aws:elasticache:us-east-1:123456789012:cluster:my-cluster-001"),
				CacheClusterStatus:     strptr("available"),
				Engine:                 strptr("redis"),
				EngineVersion:          strptr("7.1"),
				CacheNodeType:          strptr("cache.t3.micro"),
				NumCacheNodes:          aws.Int32(2),
				CacheClusterCreateTime: aws.Time(testTime),
				ConfigurationEndpoint: &types.Endpoint{
					Address: strptr("my-cluster.abc123.cfg.use1.cache.amazonaws.com"),
					Port:    aws.Int32(6379),
				},
				AtRestEncryptionEnabled:   aws.Bool(true),
				TransitEncryptionEnabled:  aws.Bool(true),
				AuthTokenEnabled:          aws.Bool(true),
				AutoMinorVersionUpgrade:   aws.Bool(true),
				CacheSubnetGroupName:      strptr("my-subnet-group"),
				PreferredAvailabilityZone: strptr("us-east-1a"),
				SecurityGroups: []types.SecurityGroupMembership{
					{
						SecurityGroupId: strptr("sg-12345"),
						Status:          strptr("active"),
					},
				},
				CacheNodes: []types.CacheNode{
					{
						CacheNodeId:              strptr("0001"),
						CacheNodeStatus:          strptr("available"),
						CacheNodeCreateTime:      aws.Time(testTime),
						CustomerAvailabilityZone: strptr("us-east-1a"),
						Endpoint: &types.Endpoint{
							Address: strptr("my-cluster-001.abc123.0001.use1.cache.amazonaws.com"),
							Port:    aws.Int32(6379),
						},
					},
					{
						CacheNodeId:              strptr("0002"),
						CacheNodeStatus:          strptr("available"),
						CacheNodeCreateTime:      aws.Time(testTime),
						CustomerAvailabilityZone: strptr("us-east-1b"),
						Endpoint: &types.Endpoint{
							Address: strptr("my-cluster-001.abc123.0002.use1.cache.amazonaws.com"),
							Port:    aws.Int32(6379),
						},
					},
				},
			},
			tags: []types.Tag{
				{Key: strptr("Environment"), Value: strptr("production")},
				{Key: strptr("Application"), Value: strptr("web-app")},
			},
			expectedTargetCount: 2,
			expectedLabels: []model.LabelSet{
				{
					"__meta_elasticache_deployment_option":                                "node",
					"__meta_elasticache_cache_cluster_arn":                                "arn:aws:elasticache:us-east-1:123456789012:cluster:my-cluster-001",
					"__meta_elasticache_cache_cluster_cache_cluster_id":                   "my-cluster-001",
					"__meta_elasticache_cache_cluster_cache_cluster_status":               "available",
					"__meta_elasticache_cache_cluster_engine":                             "redis",
					"__meta_elasticache_cache_cluster_engine_version":                     "7.1",
					"__meta_elasticache_cache_cluster_cache_node_type":                    "cache.t3.micro",
					"__meta_elasticache_cache_cluster_num_cache_nodes":                    "2",
					"__meta_elasticache_cache_cluster_cache_cluster_create_time":          "2024-01-01T00:00:00Z",
					"__meta_elasticache_cache_cluster_configuration_endpoint_address":     "my-cluster.abc123.cfg.use1.cache.amazonaws.com",
					"__meta_elasticache_cache_cluster_configuration_endpoint_port":        "6379",
					"__meta_elasticache_cache_cluster_at_rest_encryption_enabled":         "true",
					"__meta_elasticache_cache_cluster_transit_encryption_enabled":         "true",
					"__meta_elasticache_cache_cluster_auth_token_enabled":                 "true",
					"__meta_elasticache_cache_cluster_auto_minor_version_upgrade":         "true",
					"__meta_elasticache_cache_cluster_cache_subnet_group_name":            "my-subnet-group",
					"__meta_elasticache_cache_cluster_preferred_availability_zone":        "us-east-1a",
					"__meta_elasticache_cache_cluster_security_group_membership_id_0":     "sg-12345",
					"__meta_elasticache_cache_cluster_security_group_membership_status_0": "active",
					"__meta_elasticache_cache_cluster_tag_Environment":                    "production",
					"__meta_elasticache_cache_cluster_tag_Application":                    "web-app",
					"__meta_elasticache_cache_cluster_node_id":                            "0001",
					"__meta_elasticache_cache_cluster_node_status":                        "available",
					"__meta_elasticache_cache_cluster_node_create_time":                   "2024-01-01T00:00:00Z",
					"__meta_elasticache_cache_cluster_node_availability_zone":             "us-east-1a",
					"__meta_elasticache_cache_cluster_node_endpoint_address":              "my-cluster-001.abc123.0001.use1.cache.amazonaws.com",
					"__meta_elasticache_cache_cluster_node_endpoint_port":                 "6379",
					"__address__": "my-cluster-001.abc123.0001.use1.cache.amazonaws.com:6379",
				},
				{
					"__meta_elasticache_deployment_option":                                "node",
					"__meta_elasticache_cache_cluster_arn":                                "arn:aws:elasticache:us-east-1:123456789012:cluster:my-cluster-001",
					"__meta_elasticache_cache_cluster_cache_cluster_id":                   "my-cluster-001",
					"__meta_elasticache_cache_cluster_cache_cluster_status":               "available",
					"__meta_elasticache_cache_cluster_engine":                             "redis",
					"__meta_elasticache_cache_cluster_engine_version":                     "7.1",
					"__meta_elasticache_cache_cluster_cache_node_type":                    "cache.t3.micro",
					"__meta_elasticache_cache_cluster_num_cache_nodes":                    "2",
					"__meta_elasticache_cache_cluster_cache_cluster_create_time":          "2024-01-01T00:00:00Z",
					"__meta_elasticache_cache_cluster_configuration_endpoint_address":     "my-cluster.abc123.cfg.use1.cache.amazonaws.com",
					"__meta_elasticache_cache_cluster_configuration_endpoint_port":        "6379",
					"__meta_elasticache_cache_cluster_at_rest_encryption_enabled":         "true",
					"__meta_elasticache_cache_cluster_transit_encryption_enabled":         "true",
					"__meta_elasticache_cache_cluster_auth_token_enabled":                 "true",
					"__meta_elasticache_cache_cluster_auto_minor_version_upgrade":         "true",
					"__meta_elasticache_cache_cluster_cache_subnet_group_name":            "my-subnet-group",
					"__meta_elasticache_cache_cluster_preferred_availability_zone":        "us-east-1a",
					"__meta_elasticache_cache_cluster_security_group_membership_id_0":     "sg-12345",
					"__meta_elasticache_cache_cluster_security_group_membership_status_0": "active",
					"__meta_elasticache_cache_cluster_tag_Environment":                    "production",
					"__meta_elasticache_cache_cluster_tag_Application":                    "web-app",
					"__meta_elasticache_cache_cluster_node_id":                            "0002",
					"__meta_elasticache_cache_cluster_node_status":                        "available",
					"__meta_elasticache_cache_cluster_node_create_time":                   "2024-01-01T00:00:00Z",
					"__meta_elasticache_cache_cluster_node_availability_zone":             "us-east-1b",
					"__meta_elasticache_cache_cluster_node_endpoint_address":              "my-cluster-001.abc123.0002.use1.cache.amazonaws.com",
					"__meta_elasticache_cache_cluster_node_endpoint_port":                 "6379",
					"__address__": "my-cluster-001.abc123.0002.use1.cache.amazonaws.com:6379",
				},
			},
		},
		{
			name: "CacheClusterWithSingleNode",
			cluster: &types.CacheCluster{
				CacheClusterId:     strptr("node-cluster-001"),
				ARN:                strptr("arn:aws:elasticache:us-east-1:123456789012:cluster:node-cluster-001"),
				CacheClusterStatus: strptr("available"),
				Engine:             strptr("redis"),
				EngineVersion:      strptr("6.2"),
				CacheNodeType:      strptr("cache.r6g.large"),
				NumCacheNodes:      aws.Int32(1),
				CacheNodes: []types.CacheNode{
					{
						CacheNodeId:              strptr("0001"),
						CacheNodeStatus:          strptr("available"),
						CacheNodeCreateTime:      aws.Time(testTime),
						CustomerAvailabilityZone: strptr("us-east-1a"),
						Endpoint: &types.Endpoint{
							Address: strptr("node-cluster-001.abc123.0001.use1.cache.amazonaws.com"),
							Port:    aws.Int32(6379),
						},
					},
				},
			},
			tags:                []types.Tag{},
			expectedTargetCount: 1,
			expectedLabels: []model.LabelSet{
				{
					"__meta_elasticache_deployment_option":                    "node",
					"__meta_elasticache_cache_cluster_arn":                    "arn:aws:elasticache:us-east-1:123456789012:cluster:node-cluster-001",
					"__meta_elasticache_cache_cluster_cache_cluster_id":       "node-cluster-001",
					"__meta_elasticache_cache_cluster_cache_cluster_status":   "available",
					"__meta_elasticache_cache_cluster_engine":                 "redis",
					"__meta_elasticache_cache_cluster_engine_version":         "6.2",
					"__meta_elasticache_cache_cluster_cache_node_type":        "cache.r6g.large",
					"__meta_elasticache_cache_cluster_num_cache_nodes":        "1",
					"__meta_elasticache_cache_cluster_node_id":                "0001",
					"__meta_elasticache_cache_cluster_node_status":            "available",
					"__meta_elasticache_cache_cluster_node_create_time":       "2024-01-01T00:00:00Z",
					"__meta_elasticache_cache_cluster_node_availability_zone": "us-east-1a",
					"__meta_elasticache_cache_cluster_node_endpoint_address":  "node-cluster-001.abc123.0001.use1.cache.amazonaws.com",
					"__meta_elasticache_cache_cluster_node_endpoint_port":     "6379",
					"__address__": "node-cluster-001.abc123.0001.use1.cache.amazonaws.com:6379",
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tg := &targetgroup.Group{
				Source: "test",
			}

			addCacheClusterTargets(tg, tt.cluster, tt.tags)

			require.Len(t, tg.Targets, tt.expectedTargetCount)

			// Check each target
			for i, expectedLabels := range tt.expectedLabels {
				labels := tg.Targets[i]

				// Check that all expected labels are present with correct values
				for k, v := range expectedLabels {
					actualValue, exists := labels[k]
					require.True(t, exists, "label %s should exist in target %d", k, i)
					require.Equal(t, v, actualValue, "label %s mismatch in target %d", k, i)
				}
			}
		})
	}
}

// Mock Elasticache client.
type mockElasticacheClient struct {
	data *elasticacheDataStore

	// onDescribe, when set, runs at the start of every DescribeServerlessCaches
	// and DescribeCacheClusters call.
	onDescribe func()

	// describeRequests records one entry per describe call, so a test can show
	// which requests a single refresh issues.
	describeMu       sync.Mutex
	describeRequests []string
}

// recordDescribe stores a describe request, identified by the input fields the
// discovery varies between calls.
func (m *mockElasticacheClient) recordDescribe(request string) {
	m.describeMu.Lock()
	m.describeRequests = append(m.describeRequests, request)
	m.describeMu.Unlock()
}

func newMockElasticacheClient(data *elasticacheDataStore) *mockElasticacheClient {
	return &mockElasticacheClient{data: data}
}

func (m *mockElasticacheClient) DescribeServerlessCaches(_ context.Context, input *elasticache.DescribeServerlessCachesInput, _ ...func(*elasticache.Options)) (*elasticache.DescribeServerlessCachesOutput, error) {
	if m.onDescribe != nil {
		m.onDescribe()
	}
	m.recordDescribe(fmt.Sprintf("DescribeServerlessCaches name=%s token=%s",
		aws.ToString(input.ServerlessCacheName), aws.ToString(input.NextToken)))
	if input.ServerlessCacheName != nil {
		// Filter by name
		for _, cache := range m.data.serverlessCaches {
			if cache.ServerlessCacheName != nil && *cache.ServerlessCacheName == *input.ServerlessCacheName {
				return &elasticache.DescribeServerlessCachesOutput{
					ServerlessCaches: []types.ServerlessCache{cache},
				}, nil
			}
		}
		return &elasticache.DescribeServerlessCachesOutput{
			ServerlessCaches: []types.ServerlessCache{},
		}, nil
	}

	return &elasticache.DescribeServerlessCachesOutput{
		ServerlessCaches: m.data.serverlessCaches,
	}, nil
}

// DescribeCacheClusters mirrors the ShowCacheClustersNotInReplicationGroups
// filter: when it is set, only clusters that are not members of a replication
// group are returned; when it is unset or false the API returns every cluster,
// replication group members included.
func (m *mockElasticacheClient) DescribeCacheClusters(_ context.Context, input *elasticache.DescribeCacheClustersInput, _ ...func(*elasticache.Options)) (*elasticache.DescribeCacheClustersOutput, error) {
	if m.onDescribe != nil {
		m.onDescribe()
	}
	m.recordDescribe(fmt.Sprintf("DescribeCacheClusters id=%s marker=%s notInReplicationGroups=%t",
		aws.ToString(input.CacheClusterId), aws.ToString(input.Marker),
		aws.ToBool(input.ShowCacheClustersNotInReplicationGroups)))

	notInReplicationGroupsOnly := aws.ToBool(input.ShowCacheClustersNotInReplicationGroups)

	clusters := []types.CacheCluster{}
	for _, cluster := range m.data.cacheClusters {
		// Single cluster lookup.
		if input.CacheClusterId != nil &&
			(cluster.CacheClusterId == nil || *cluster.CacheClusterId != *input.CacheClusterId) {
			continue
		}
		if notInReplicationGroupsOnly && cluster.ReplicationGroupId != nil {
			continue
		}
		clusters = append(clusters, cluster)
	}

	return &elasticache.DescribeCacheClustersOutput{
		CacheClusters: clusters,
	}, nil
}

func (m *mockElasticacheClient) ListTagsForResource(_ context.Context, input *elasticache.ListTagsForResourceInput, _ ...func(*elasticache.Options)) (*elasticache.ListTagsForResourceOutput, error) {
	if input.ResourceName != nil {
		if tags, ok := m.data.tags[*input.ResourceName]; ok {
			return &elasticache.ListTagsForResourceOutput{
				TagList: tags,
			}, nil
		}
	}

	return &elasticache.ListTagsForResourceOutput{
		TagList: []types.Tag{},
	}, nil
}

func TestSplitCacheDeploymentOptions(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name                       string
		caches                     []string
		expectedServerlessCacheIDs []string
		expectedCacheClusterIDs    []string
	}{
		{
			name: "MixedARNs",
			caches: []string{
				"arn:aws:elasticache:us-east-1:123456789012:serverlesscache:my-serverless-cache",
				"arn:aws:elasticache:us-east-1:123456789012:replicationgroup:my-replication-group",
				"arn:aws:elasticache:us-west-2:123456789012:serverlesscache:prod-cache",
			},
			expectedServerlessCacheIDs: []string{"my-serverless-cache", "prod-cache"},
			expectedCacheClusterIDs:    []string{"my-replication-group"},
		},
		{
			name: "OnlyServerlessCaches",
			caches: []string{
				"arn:aws:elasticache:us-east-1:123456789012:serverlesscache:cache-1",
				"arn:aws:elasticache:us-east-1:123456789012:serverlesscache:cache-2",
			},
			expectedServerlessCacheIDs: []string{"cache-1", "cache-2"},
			expectedCacheClusterIDs:    nil,
		},
		{
			name: "OnlyReplicationGroups",
			caches: []string{
				"arn:aws:elasticache:us-east-1:123456789012:replicationgroup:cluster-1",
				"arn:aws:elasticache:us-east-1:123456789012:replicationgroup:cluster-2",
			},
			expectedServerlessCacheIDs: nil,
			expectedCacheClusterIDs:    []string{"cluster-1", "cluster-2"},
		},
		{
			name:                       "EmptyInput",
			caches:                     []string{},
			expectedServerlessCacheIDs: nil,
			expectedCacheClusterIDs:    nil,
		},
		{
			name: "InvalidARNs",
			caches: []string{
				"not-an-arn",
				"arn:aws:elasticache:us-east-1",
				"arn:aws:elasticache:us-east-1:123456789012:serverlesscache",
				"",
			},
			expectedServerlessCacheIDs: nil,
			expectedCacheClusterIDs:    nil,
		},
		{
			name: "UnknownResourceType",
			caches: []string{
				"arn:aws:elasticache:us-east-1:123456789012:unknown:resource-id",
			},
			expectedServerlessCacheIDs: nil,
			expectedCacheClusterIDs:    nil,
		},
		{
			name: "MixedWithInvalidARNs",
			caches: []string{
				"arn:aws:elasticache:us-east-1:123456789012:serverlesscache:valid-cache",
				"invalid-arn",
				"arn:aws:elasticache:us-east-1:123456789012:replicationgroup:valid-cluster",
				"",
				"arn:aws:elasticache:us-east-1:123456789012:unknown:ignored",
			},
			expectedServerlessCacheIDs: []string{"valid-cache"},
			expectedCacheClusterIDs:    []string{"valid-cluster"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			serverlessCacheIDs, cacheClusterIDs := splitCacheDeploymentOptions(tt.caches, promslog.NewNopLogger())

			require.Equal(t, tt.expectedServerlessCacheIDs, serverlessCacheIDs, "serverless cache IDs mismatch")
			require.Equal(t, tt.expectedCacheClusterIDs, cacheClusterIDs, "cache cluster IDs mismatch")
		})
	}
}

// elasticacheTestDiscovery returns a discovery backed by the mock client, so
// refresh() can be exercised without reaching AWS. initElasticacheClient returns
// early when elasticacheClient is already set, which also leaves region unset,
// so it is populated here.
func elasticacheTestDiscovery(data *elasticacheDataStore) *ElasticacheDiscovery {
	return &ElasticacheDiscovery{
		logger:            promslog.NewNopLogger(),
		elasticacheClient: newMockElasticacheClient(data),
		cfg: &ElasticacheSDConfig{
			Region:             data.region,
			RequestConcurrency: 10,
		},
		region: data.region,
	}
}

// fullyPopulatedServerlessCache is the shape the AWS API returns when every
// optional field happens to be set. Each subtest below blanks exactly one of
// them.
func fullyPopulatedServerlessCache() types.ServerlessCache {
	return types.ServerlessCache{
		ARN:                 strptr("arn:aws:elasticache:us-east-1:123456789012:serverlesscache:my-cache"),
		ServerlessCacheName: strptr("my-cache"),
		Status:              strptr("available"),
		Engine:              strptr("redis"),
		FullEngineVersion:   strptr("7.1"),
		MajorEngineVersion:  strptr("7"),
		Endpoint: &types.Endpoint{
			Address: strptr("my-cache.serverless.use1.cache.amazonaws.com"),
			Port:    aws.Int32(6379),
		},
	}
}

// fullyPopulatedCacheCluster mirrors fullyPopulatedServerlessCache for the
// node-based deployment option.
func fullyPopulatedCacheCluster() types.CacheCluster {
	return types.CacheCluster{
		ARN:                strptr("arn:aws:elasticache:us-east-1:123456789012:cluster:my-cluster-001"),
		CacheClusterId:     strptr("my-cluster-001"),
		CacheClusterStatus: strptr("available"),
		CacheNodes: []types.CacheNode{
			{
				CacheNodeId: strptr("0001"),
				Endpoint: &types.Endpoint{
					Address: strptr("my-cluster-001.abc123.0001.use1.cache.amazonaws.com"),
					Port:    aws.Int32(6379),
				},
			},
		},
	}
}

// TestElasticacheRefreshFullyPopulated pins the happy path so the nil handling
// added for the cases below cannot silently drop labels that used to be set.
func TestElasticacheRefreshFullyPopulated(t *testing.T) {
	t.Parallel()

	tgs, err := elasticacheTestDiscovery(&elasticacheDataStore{
		region:           "us-east-1",
		serverlessCaches: []types.ServerlessCache{fullyPopulatedServerlessCache()},
		cacheClusters:    []types.CacheCluster{fullyPopulatedCacheCluster()},
		tags: map[string][]types.Tag{
			"arn:aws:elasticache:us-east-1:123456789012:serverlesscache:my-cache": {
				{Key: strptr("Environment"), Value: strptr("test")},
			},
			"arn:aws:elasticache:us-east-1:123456789012:cluster:my-cluster-001": {
				{Key: strptr("Environment"), Value: strptr("prod")},
			},
		},
	}).refresh(context.Background())
	require.NoError(t, err)
	require.Len(t, tgs, 1)

	require.Len(t, tgs[0].Targets, 2, "one target per deployment option, and no duplicates")

	targetsByOption := map[model.LabelValue]model.LabelSet{}
	for _, target := range tgs[0].Targets {
		targetsByOption[target[elasticacheLabelDeploymentOption]] = target
	}
	require.Len(t, targetsByOption, 2, "both deployment options must be discovered")

	serverless := targetsByOption["serverless"]
	require.Equal(t, model.LabelValue("my-cache.serverless.use1.cache.amazonaws.com:6379"), serverless[model.AddressLabel])
	require.Equal(t, model.LabelValue("arn:aws:elasticache:us-east-1:123456789012:serverlesscache:my-cache"), serverless[elasticacheLabelServerlessCacheARN])
	require.Equal(t, model.LabelValue("my-cache"), serverless[elasticacheLabelServerlessCacheName])
	require.Equal(t, model.LabelValue("available"), serverless[elasticacheLabelServerlessCacheStatus])
	require.Equal(t, model.LabelValue("redis"), serverless[elasticacheLabelServerlessCacheEngine])
	require.Equal(t, model.LabelValue("7.1"), serverless[elasticacheLabelServerlessCacheFullEngineVersion])
	require.Equal(t, model.LabelValue("7"), serverless[elasticacheLabelServerlessCacheMajorEngineVersion])
	require.Equal(t, model.LabelValue("test"), serverless[elasticacheLabelServerlessCacheTag+"Environment"])

	node := targetsByOption["node"]
	require.Equal(t, model.LabelValue("my-cluster-001.abc123.0001.use1.cache.amazonaws.com:6379"), node[model.AddressLabel])
	require.Equal(t, model.LabelValue("arn:aws:elasticache:us-east-1:123456789012:cluster:my-cluster-001"), node[elasticacheLabelCacheClusterARN])
	require.Equal(t, model.LabelValue("my-cluster-001"), node[elasticacheLabelCacheClusterID])
	require.Equal(t, model.LabelValue("available"), node[elasticacheLabelCacheClusterStatus])
	require.Equal(t, model.LabelValue("prod"), node[elasticacheLabelCacheClusterTag+"Environment"])
}

// TestElasticacheRefreshServerlessCacheNilOptionalFields covers serverless
// caches where the AWS API omitted an optional field. None of the members of
// ServerlessCache are marked required by the SDK, yet refresh() dereferenced
// these without a nil check, so a single missing field panicked the whole
// Prometheus process during service discovery rather than degrading the target.
func TestElasticacheRefreshServerlessCacheNilOptionalFields(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name   string
		mutate func(*types.ServerlessCache)
		absent model.LabelName
	}{
		{
			name:   "NilARN",
			mutate: func(c *types.ServerlessCache) { c.ARN = nil },
			absent: elasticacheLabelServerlessCacheARN,
		},
		{
			name:   "NilServerlessCacheName",
			mutate: func(c *types.ServerlessCache) { c.ServerlessCacheName = nil },
			absent: elasticacheLabelServerlessCacheName,
		},
		{
			name:   "NilStatus",
			mutate: func(c *types.ServerlessCache) { c.Status = nil },
			absent: elasticacheLabelServerlessCacheStatus,
		},
		{
			name:   "NilEngine",
			mutate: func(c *types.ServerlessCache) { c.Engine = nil },
			absent: elasticacheLabelServerlessCacheEngine,
		},
		{
			name:   "NilFullEngineVersion",
			mutate: func(c *types.ServerlessCache) { c.FullEngineVersion = nil },
			absent: elasticacheLabelServerlessCacheFullEngineVersion,
		},
		{
			name:   "NilMajorEngineVersion",
			mutate: func(c *types.ServerlessCache) { c.MajorEngineVersion = nil },
			absent: elasticacheLabelServerlessCacheMajorEngineVersion,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			cache := fullyPopulatedServerlessCache()
			tc.mutate(&cache)

			tgs, err := elasticacheTestDiscovery(&elasticacheDataStore{
				region:           "us-east-1",
				serverlessCaches: []types.ServerlessCache{cache},
			}).refresh(context.Background())
			require.NoError(t, err)
			require.Len(t, tgs, 1)
			require.Len(t, tgs[0].Targets, 1,
				"cache must still be discovered when an optional field is absent")

			target := tgs[0].Targets[0]
			require.NotContains(t, target, tc.absent,
				"label sourced from the absent field should be omitted")
			// The cache is still usable: the address is what makes it a target.
			require.Equal(t, model.LabelValue("my-cache.serverless.use1.cache.amazonaws.com:6379"), target[model.AddressLabel])
		})
	}
}

// TestElasticacheRefreshCacheClusterNilOptionalFields is the node deployment
// counterpart of TestElasticacheRefreshServerlessCacheNilOptionalFields.
func TestElasticacheRefreshCacheClusterNilOptionalFields(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name   string
		mutate func(*types.CacheCluster)
		absent model.LabelName
	}{
		{
			name:   "NilARN",
			mutate: func(c *types.CacheCluster) { c.ARN = nil },
			absent: elasticacheLabelCacheClusterARN,
		},
		{
			name:   "NilCacheClusterId",
			mutate: func(c *types.CacheCluster) { c.CacheClusterId = nil },
			absent: elasticacheLabelCacheClusterID,
		},
		{
			name:   "NilCacheClusterStatus",
			mutate: func(c *types.CacheCluster) { c.CacheClusterStatus = nil },
			absent: elasticacheLabelCacheClusterStatus,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			cluster := fullyPopulatedCacheCluster()
			tc.mutate(&cluster)

			tgs, err := elasticacheTestDiscovery(&elasticacheDataStore{
				region:        "us-east-1",
				cacheClusters: []types.CacheCluster{cluster},
			}).refresh(context.Background())
			require.NoError(t, err)
			require.Len(t, tgs, 1)
			require.Len(t, tgs[0].Targets, 1,
				"cluster node must still be discovered when an optional field is absent")

			target := tgs[0].Targets[0]
			require.NotContains(t, target, tc.absent,
				"label sourced from the absent field should be omitted")
			require.Equal(t, model.LabelValue("my-cluster-001.abc123.0001.use1.cache.amazonaws.com:6379"), target[model.AddressLabel])
		})
	}
}

// elasticacheFixture builds a data store holding serverlessCount serverless
// caches and clusterCount cache clusters, every cluster carrying nodeCount
// nodes.
func elasticacheFixture(serverlessCount, clusterCount, nodeCount int) *elasticacheDataStore {
	data := &elasticacheDataStore{
		region: "us-east-1",
		tags:   make(map[string][]types.Tag, serverlessCount+clusterCount),
	}

	for s := range serverlessCount {
		name := "serverless-" + strconv.Itoa(s)
		arn := "arn:aws:elasticache:us-east-1:123456789012:serverlesscache:" + name
		cache := fullyPopulatedServerlessCache()
		cache.ARN = strptr(arn)
		cache.ServerlessCacheName = strptr(name)
		cache.Endpoint = &types.Endpoint{
			Address: strptr(name + ".serverless.use1.cache.amazonaws.com"),
			Port:    aws.Int32(6379),
		}
		data.serverlessCaches = append(data.serverlessCaches, cache)
		data.tags[arn] = []types.Tag{{Key: strptr("Environment"), Value: strptr("bench")}}
	}

	for c := range clusterCount {
		id := "cluster-" + strconv.Itoa(c)
		arn := "arn:aws:elasticache:us-east-1:123456789012:cluster:" + id
		cluster := fullyPopulatedCacheCluster()
		cluster.ARN = strptr(arn)
		cluster.CacheClusterId = strptr(id)
		cluster.CacheNodes = make([]types.CacheNode, 0, nodeCount)
		for n := range nodeCount {
			cluster.CacheNodes = append(cluster.CacheNodes, types.CacheNode{
				CacheNodeId: strptr(fmt.Sprintf("%04d", n+1)),
				Endpoint: &types.Endpoint{
					Address: strptr(fmt.Sprintf("%s-%04d.use1.cache.amazonaws.com", id, n+1)),
					Port:    aws.Int32(6379),
				},
			})
		}
		data.cacheClusters = append(data.cacheClusters, cluster)
		data.tags[arn] = []types.Tag{{Key: strptr("Environment"), Value: strptr("bench")}}
	}

	return data
}

// distinctTargetAddresses counts the unique addresses in a target group, which
// is what the fixture size predicts however many times the API reported the
// same resource.
func distinctTargetAddresses(tg *targetgroup.Group) int {
	addresses := make(map[model.LabelValue]struct{}, len(tg.Targets))
	for _, target := range tg.Targets {
		addresses[target[model.AddressLabel]] = struct{}{}
	}
	return len(addresses)
}

func BenchmarkElasticacheRefresh(b *testing.B) {
	benchmarks := []struct {
		name       string
		serverless int
		clusters   int
		nodes      int
	}{
		{"1Serverless/1Cluster", 1, 1, 1},
		{"8Serverless/8Clusters", 8, 8, 1},
		{"20Serverless/20Clusters", 20, 20, 2},
	}

	for _, bm := range benchmarks {
		b.Run(bm.name, func(b *testing.B) {
			d := elasticacheTestDiscovery(elasticacheFixture(bm.serverless, bm.clusters, bm.nodes))
			want := bm.serverless + bm.clusters*bm.nodes

			b.ReportAllocs()
			for b.Loop() {
				tgs, err := d.refresh(context.Background())
				if err != nil {
					b.Fatal(err)
				}
				if got := distinctTargetAddresses(tgs[0]); got != want {
					b.Fatalf("got %d distinct targets, want %d", got, want)
				}
			}
		})
	}
}

// BenchmarkElasticacheRefreshAPILatency models the describe round trip, which
// dominates a refresh and which BenchmarkElasticacheRefresh cannot show because
// its client answers instantly. The absolute latency is arbitrary; the ratio
// between the two benchmarks is what the number says.
func BenchmarkElasticacheRefreshAPILatency(b *testing.B) {
	const (
		resourceCount = 20
		roundTrip     = time.Millisecond
	)
	data := elasticacheFixture(resourceCount, resourceCount, 1)

	client := newMockElasticacheClient(data)
	client.onDescribe = func() { time.Sleep(roundTrip) }
	d := &ElasticacheDiscovery{
		logger:            promslog.NewNopLogger(),
		elasticacheClient: client,
		cfg: &ElasticacheSDConfig{
			Region:             data.region,
			RequestConcurrency: 10,
		},
		region: data.region,
	}

	b.ReportAllocs()
	for b.Loop() {
		tgs, err := d.refresh(context.Background())
		if err != nil {
			b.Fatal(err)
		}
		if got := distinctTargetAddresses(tgs[0]); got != resourceCount*2 {
			b.Fatalf("got %d distinct targets, want %d", got, resourceCount*2)
		}
	}
}

// TestElasticacheRefreshDescribesEachResourceOnce covers refresh() asking the
// API for the same resources twice: once to collect the ARNs the tag lookup
// needs, and once more to build the targets. Both rounds send identical
// requests and get identical answers, so the second one only spends the
// account's API quota.
func TestElasticacheRefreshDescribesEachResourceOnce(t *testing.T) {
	t.Parallel()

	data := elasticacheFixture(2, 2, 1)
	client := newMockElasticacheClient(data)
	d := &ElasticacheDiscovery{
		logger:            promslog.NewNopLogger(),
		elasticacheClient: client,
		cfg: &ElasticacheSDConfig{
			Region:             data.region,
			RequestConcurrency: 10,
		},
		region: data.region,
	}

	_, err := d.refresh(context.Background())
	require.NoError(t, err)

	counts := make(map[string]int, len(client.describeRequests))
	for _, request := range client.describeRequests {
		counts[request]++
	}

	var repeated []string
	for request, count := range counts {
		if count > 1 {
			repeated = append(repeated, fmt.Sprintf("%s: %d times", request, count))
		}
	}
	slices.Sort(repeated)
	require.Empty(t, repeated, "a refresh must not issue the same describe request more than once")
}

// TestElasticacheDescribeCacheClustersReturnsEachClusterOnce guards against
// describing the same cluster twice. DescribeCacheClusters returns every
// provisioned cluster unless ShowCacheClustersNotInReplicationGroups is set, in
// which case it returns only the subset that are not replication group members,
// so querying with and without the flag and concatenating both responses yields
// every standalone cluster twice.
func TestElasticacheDescribeCacheClustersReturnsEachClusterOnce(t *testing.T) {
	t.Parallel()

	for _, tt := range []struct {
		name        string
		clusterIDs  []string
		expectedIDs []string
	}{
		{
			name:        "AllClusters",
			clusterIDs:  nil,
			expectedIDs: []string{"standalone-001", "member-001"},
		},
		{
			name:        "StandaloneClusterByID",
			clusterIDs:  []string{"standalone-001"},
			expectedIDs: []string{"standalone-001"},
		},
		{
			name:        "ReplicationGroupMemberByID",
			clusterIDs:  []string{"member-001"},
			expectedIDs: []string{"member-001"},
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			d := &ElasticacheDiscovery{
				elasticacheClient: newMockElasticacheClient(&elasticacheDataStore{
					region: "us-east-1",
					cacheClusters: []types.CacheCluster{
						// Memcached and single node clusters are not members of
						// a replication group, so both API responses carry them.
						{CacheClusterId: strptr("standalone-001")},
						{
							CacheClusterId:     strptr("member-001"),
							ReplicationGroupId: strptr("my-replication-group"),
						},
					},
				}),
				cfg: &ElasticacheSDConfig{
					Region:             "us-east-1",
					RequestConcurrency: 10,
				},
			}

			clusters, err := d.describeCacheClusters(context.Background(), tt.clusterIDs)
			require.NoError(t, err)

			ids := make([]string, 0, len(clusters))
			for _, cluster := range clusters {
				ids = append(ids, aws.ToString(cluster.CacheClusterId))
			}
			require.ElementsMatch(t, tt.expectedIDs, ids,
				"each cluster must be described exactly once")
		})
	}
}
