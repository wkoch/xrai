cfg_rt! {
    #[cfg(not(target_os = "emscripten"))]
    pub(crate) use crate::runtime::spawn_blocking;

    cfg_io_blocking! {
        #[cfg(not(target_os = "emscripten"))]
        #[allow(unused_imports)]
        pub(crate) use crate::runtime::spawn_mandatory_blocking;
    }

    #[cfg(not(target_os = "emscripten"))]
    pub(crate) use crate::task::JoinHandle;

    // Emscripten's filesystem is synchronous, so `fs` and `io-std` run inline
    // here, pthread builds included. Public `task::spawn_blocking` is unaffected.
    //
    // The completed future is wrapped in `Coop` so that polling it consumes
    // task budget exactly like the native `task::JoinHandle::poll` does. The
    // `fs` and `io-std` consumers rely on that budget for their yield points:
    // without it a loop of always-ready file reads never returns `Pending`
    // and starves every other task on the single-threaded runtime.
    #[cfg(target_os = "emscripten")]
    pub(crate) type JoinHandle<T> =
        crate::task::coop::Coop<std::future::Ready<Result<T, crate::task::JoinError>>>;

    #[cfg(target_os = "emscripten")]
    pub(crate) fn spawn_blocking<F, R>(f: F) -> JoinHandle<R>
    where
        F: FnOnce() -> R + Send + 'static,
        R: Send + 'static,
    {
        crate::task::coop::cooperative(std::future::ready(Ok(f())))
    }

    #[cfg(all(target_os = "emscripten", any(feature = "fs", feature = "io-std")))]
    // `fs` unit tests use the `fs::mocks` version instead, so this is unused
    // when `io-std` is disabled.
    #[allow(dead_code)]
    pub(crate) fn spawn_mandatory_blocking<F, R>(f: F) -> Option<JoinHandle<R>>
    where
        F: FnOnce() -> R + Send + 'static,
        R: Send + 'static,
    {
        Some(spawn_blocking(f))
    }
}

cfg_not_rt! {
    use std::fmt;
    use std::future::Future;
    use std::pin::Pin;
    use std::task::{Context, Poll};

    pub(crate) fn spawn_blocking<F, R>(_f: F) -> JoinHandle<R>
    where
        F: FnOnce() -> R + Send + 'static,
        R: Send + 'static,
    {
        assert_send_sync::<JoinHandle<std::cell::Cell<()>>>();
        panic!("requires the `rt` Tokio feature flag")
    }

    cfg_io_blocking! {
        pub(crate) fn spawn_mandatory_blocking<F, R>(_f: F) -> Option<JoinHandle<R>>
        where
            F: FnOnce() -> R + Send + 'static,
            R: Send + 'static,
        {
            panic!("requires the `rt` Tokio feature flag")
        }
    }

    pub(crate) struct JoinHandle<R> {
        _p: std::marker::PhantomData<R>,
    }

    unsafe impl<T: Send> Send for JoinHandle<T> {}
    unsafe impl<T: Send> Sync for JoinHandle<T> {}

    impl<R> Future for JoinHandle<R> {
        type Output = Result<R, std::io::Error>;

        fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            unreachable!()
        }
    }

    impl<T> fmt::Debug for JoinHandle<T>
    where
        T: fmt::Debug,
    {
        fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
            fmt.debug_struct("JoinHandle").finish()
        }
    }

    fn assert_send_sync<T: Send + Sync>() {
    }
}
