use crate::fs::asyncify;

use std::{io, path::Path};

/// Reads the entire contents of a file into a bytes vector.
///
/// This is an async version of [`std::fs::read`].
///
/// This is a convenience function for using [`File::open`] and [`read_to_end`]
/// with fewer imports and without an intermediate variable. It pre-allocates a
/// buffer based on the file size when available, so it is generally faster than
/// reading into a vector created with `Vec::new()`.
///
/// This operation is implemented by running the equivalent blocking operation
/// on a separate thread pool using [`spawn_blocking`].
///
/// [`File::open`]: super::File::open
/// [`read_to_end`]: crate::io::AsyncReadExt::read_to_end
/// [`spawn_blocking`]: crate::task::spawn_blocking
///
/// # Errors
///
/// This function will return an error if `path` does not already exist.
/// Other errors may also be returned according to [`OpenOptions::open`].
///
/// [`OpenOptions::open`]: super::OpenOptions::open
///
/// It will also return an error if it encounters while reading an error
/// of a kind other than [`ErrorKind::Interrupted`].
///
/// [`ErrorKind::Interrupted`]: std::io::ErrorKind::Interrupted
///
/// # io_uring support
///
/// On Linux, you can also use io_uring for executing system calls. To enable
/// io_uring, you need to specify the `--cfg tokio_unstable` flag at compile time,
/// enable the io-uring cargo feature, and set the `Builder::enable_io_uring`
/// runtime option.
///
/// Support for io_uring is currently experimental, so its behavior may change
/// or it may be removed in future versions.
///
/// # Examples
///
/// ```no_run
/// use tokio::fs;
/// use std::net::SocketAddr;
///
/// #[tokio::main]
/// async fn main() -> Result<(), Box<dyn std::error::Error + 'static>> {
///     let contents = fs::read("address.txt").await?;
///     let foo: SocketAddr = String::from_utf8_lossy(&contents).parse()?;
///     Ok(())
/// }
/// ```
pub async fn read(path: impl AsRef<Path>) -> io::Result<Vec<u8>> {
    let path = path.as_ref();

    #[cfg(all(
        tokio_unstable,
        feature = "io-uring",
        feature = "rt",
        feature = "fs",
        // libc::statx is only supported on these platforms
        // FIXME: Add musl target env when our minimum supported
        // rust version is 1.93. To clarify, statx support is
        // introduced to musl in 1.25 as mentioned officially here:
        // https://musl.libc.org/releases.html.
        // However, rustup target_env building for *-linux-musl
        // uses 1.25 musl on all *-linux-musl platforms starting
        // in 1.93 stable rust version.
        // https://blog.rust-lang.org/2025/12/05/Updating-musl-1.2.5/
        any(target_env = "gnu", target_os = "android")
    ))]
    {
        use crate::fs::read_uring;

        if let Ok(handle) = crate::runtime::Handle::try_current() {
            if let Some(driver_handle) = handle.inner.driver().io.as_ref() {
                if driver_handle
                    .check_and_init(io_uring::opcode::Read::CODE)
                    .await?
                {
                    return read_uring(path).await;
                }
            }
        }
    }

    read_spawn_blocking(path).await
}

async fn read_spawn_blocking(path: &Path) -> io::Result<Vec<u8>> {
    let path = path.to_owned();
    asyncify(move || std::fs::read(path)).await
}
