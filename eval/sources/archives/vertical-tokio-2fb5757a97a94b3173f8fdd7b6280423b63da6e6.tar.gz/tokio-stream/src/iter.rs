use crate::Stream;

use core::pin::Pin;
use core::task::{Context, Poll};

/// Stream for the [`iter`](fn@iter) function.
#[derive(Debug)]
#[must_use = "streams do nothing unless polled"]
pub struct Iter<I> {
    iter: I,
    #[cfg(not(feature = "rt"))]
    yield_amt: usize,
}

impl<I> Unpin for Iter<I> {}

/// Converts an `Iterator` into a `Stream`.
///
/// Iterators in Rust don't express the ability to block, so this adapter
/// calls `iter.next()` to obtain the next value. It may return
/// `Poll::Pending` to cooperate with the executor.
///
/// ```
/// # async fn dox() {
/// use tokio_stream::{self as stream, StreamExt};
///
/// let mut stream = stream::iter(vec![17, 19]);
///
/// assert_eq!(stream.next().await, Some(17));
/// assert_eq!(stream.next().await, Some(19));
/// assert_eq!(stream.next().await, None);
/// # }
/// ```
pub fn iter<I>(i: I) -> Iter<I::IntoIter>
where
    I: IntoIterator,
{
    Iter {
        iter: i.into_iter(),
        #[cfg(not(feature = "rt"))]
        yield_amt: 0,
    }
}

impl<I> Stream for Iter<I>
where
    I: Iterator,
{
    type Item = I::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<I::Item>> {
        #[cfg(feature = "rt")]
        {
            use tokio::task::coop;

            let coop = std::task::ready!(coop::poll_proceed(cx));
            let item = self.iter.next();

            coop.made_progress();

            Poll::Ready(item)
        }

        #[cfg(not(feature = "rt"))]
        {
            if self.yield_amt >= 32 {
                self.yield_amt = 0;

                cx.waker().wake_by_ref();

                Poll::Pending
            } else {
                let item = self.iter.next();

                self.yield_amt += 1;

                Poll::Ready(item)
            }
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}
