use crate::Stream;

use core::fmt;
use core::pin::Pin;
use core::task::{ready, Context, Poll};
use futures_core::FusedStream;
use pin_project_lite::pin_project;

pin_project! {
    /// Stream for the [`skip_while`](super::StreamExt::skip_while) method.
    #[must_use = "streams do nothing unless polled"]
    pub struct SkipWhile<St, F> {
        #[pin]
        stream: St,
        predicate: Option<F>,
    }
}

impl<St, F> fmt::Debug for SkipWhile<St, F>
where
    St: fmt::Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SkipWhile")
            .field("stream", &self.stream)
            .finish()
    }
}

impl<St, F> SkipWhile<St, F> {
    pub(super) fn new(stream: St, predicate: F) -> Self {
        Self {
            stream,
            predicate: Some(predicate),
        }
    }

    /// Returns a reference to the inner stream.
    pub fn get_ref(&self) -> &St {
        &self.stream
    }

    /// Returns a mutable reference to the inner stream.
    ///
    /// Mutating the inner stream may confuse this combinator.
    pub fn get_mut(&mut self) -> &mut St {
        &mut self.stream
    }

    /// Returns a pinned mutable reference to the inner stream.
    ///
    /// Mutating the inner stream may confuse this combinator.
    pub fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut St> {
        self.project().stream
    }

    /// Consumes this combinator and returns the inner stream.
    ///
    /// This may discard intermediate combinator state.
    pub fn into_inner(self) -> St {
        self.stream
    }
}

impl<St, F> Stream for SkipWhile<St, F>
where
    St: Stream,
    F: FnMut(&St::Item) -> bool,
{
    type Item = St::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let mut this = self.project();
        if let Some(predicate) = this.predicate {
            loop {
                match ready!(this.stream.as_mut().poll_next(cx)) {
                    Some(item) => {
                        if !(predicate)(&item) {
                            *this.predicate = None;
                            return Poll::Ready(Some(item));
                        }
                    }
                    None => return Poll::Ready(None),
                }
            }
        } else {
            this.stream.poll_next(cx)
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let (lower, upper) = self.stream.size_hint();

        if self.predicate.is_some() {
            return (0, upper);
        }

        (lower, upper)
    }
}

impl<St, F> FusedStream for SkipWhile<St, F>
where
    St: FusedStream,
    F: FnMut(&St::Item) -> bool,
{
    fn is_terminated(&self) -> bool {
        self.stream.is_terminated()
    }
}
